# VIEWConversions

Includes conversions from Oracle to Postgresql and Maria via Ispirer tool

# QueryConversions

Query conversions from Oracle to Postgresql and MariaDB using Ispirer tool

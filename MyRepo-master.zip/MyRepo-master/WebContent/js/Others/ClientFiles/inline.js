﻿/*--Keyoti js--*/
//Version 2.0d (RapidSpell Web assembly version 3.6.0 onwards)
//Copyright Keyoti Inc. 2005-2012
//This code is not to be modified, copied or used without a license in any form.

var rsS50=new Array("",
"rswinline",
"INACTIVE",
"RS_ContextMenuTable",
"RS_CMItemSeparator",
"RS_ContextMenuItem",
"RS_ContextMenuItem_AllSubItem",
"RS_ContextMenuItem_Disabled",
"oldBrowserBox",
"undefined",
"Mac",
"\n",
"MSIE 9.",
"CSS1Compat",
":",
" ",
"rsw_ignorePropertyChange",
"oldValue",
"DIV",
"_D",
"class",
"style",
"display:none;width:1px; height:1px;position:absolute;",
"body",
"none",
"pwHtmlBox",
"div",
"__RSFIX",
"absolute",
"textarea",
"BackCompat",
"Gecko",
"px",
"scroll",
"paddingLeft",
"paddingRight",
"borderLeftWidth",
"borderRightWidth",
"paddingTop",
"paddingBottom",
"borderTopWidth",
"borderBottomWidth",
"zIndex",
"position",
"left",
"right",
"top",
"display",
"overflow",
"resize",
"bottom",
"width",
"height",
"scrollbar",
"border",
"css",
"get",
"set",
"Moz",
"whiteSpace",
"word",
"text",
"remove",
"item",
"margin",
"clip",
"visibility",
"line",
"table",
"max",
"min",
"visible",
"backgroundColor",
"transparent",
"text/xml",
"Msxml2.XMLHTTP",
"Microsoft.XMLHTTP",
"POST",
"Content-Type",
"text/xml; charset=UTF-8",
"Safari",
"application/xml",
"<",
">",
"</",
"<input type=hidden name=",
" value='",
"'>",
"function",
"'",
"','",
"<form accept-charset='UTF-8' action='",
"' method='post'>",
"<input type='hidden' name='textToCheck' value=''><input type='hidden' name='IAW' value=''>",
"</form>",
"|",
"<r><resp>xml</resp><textToCheck>",
"</textToCheck><IAW>",
"</IAW>",
"</r>",
"\r",
"Sorry, a textbox with ID=",
" couldn't be found - please check the TextComponentID or TextComponentName property.",
"_IF",
"No suggestions",
"Ignore All",
"All",
"Add",
"Edit...",
"Remove duplicate word",
"Checking...",
"Resume Editing",
"Check Spelling",
"No Spelling Errors In Text.",
"Sorry the server has failed to respond to the spell check request. Please check the URL set in the RapidSpellWebInlinePage property in the RapidSpellWebInline ctrl.",
"Textbox with ID=",
" could not be found, please check the TextComponentID property in the RapidSpell control.",
"regTB",
"rich",
"true",
"IgnoreXML",
"True",
"ACTIVE",
"debug",
"\r\n",
"starting check",
"spellcheckfinish",
"(true,-1)",
"EDITING",
"()",
"TRANSITION-CHECKING",
"before:",
"\r\nafter:",
" **abort",
"setting caret",
"block",
"overlay",
"CHECKING",
"server responded ",
" errors",
" **abort rsw_key_downed_flag. rsw_key_down_timeout=",
" flag=",
" lim=",
"caret at:",
",",
"reset caret2",
"(true,numberOfErrors)",
"id='resultContent'>",
"id='numberOfErrors'>",
"</div>",
"The page holding the RapidSpellWInlineHelper control couldn't be found, please check the URL in the RapidSpellWInlineHelperPage property, it should be set to the URL of the page holding the RapidSpellWInlineHelper control.",
"The page holding the RapidSpellWInlineHelper control returned a 500 server error - which means the page has an error, please visit the URL specified in the RapidSpellWInlineHelperPage to debug this page. ",
"(HINT: Most likely, you need to add validateRequest='false' to the Page directive if you are spell checking HTML content.)",
"There was a problem with the request, please check the URL set in the RapidSpellWInlineHelperPage property. Http Error Code: ",
"There was a problem with the request. Http Error Code: ",
"BR",
"<fo",
"rm accept-charset='UTF-8' action='",
"<input type='hidden' name='action' value='add'>",
"UserDictionaryFile",
"<r><action>add</action><w>",
"</w><UserDictionaryFile>",
"</UserDictionaryFile></r>",
"The page holding the RapidSpellWInlineHelper control couldn't be found, please check the URL in the RapidSpellWInlineHelperPage property, it should be set to the URL of the page holding RapidSpellWInlineHelperPage.",
"The page holding the RapidSpellWInlineHelper control returned a 500 server error - which means the page has an error, please visit the URL specified in the RapidSpellWInlineHelperPage to debug this page. (HINT: Most likely, you need to add validateRequest='false' to the Page directive if you are spell checking HTML content.)",
"id='errorContent'>",
"if (rsw_activeTextbox.recordCaretPos) rsw_activeTextbox.recordCaretPos();",
".",
"MSIE",
"setTimeout( function() { rsw_onFinish(",
", ",
");}, 100 ); ",
"boolean",
"LINK",
"text/css",
"href",
"rel",
"stylesheet",
"head",
"rs_err_hl",
"className",
"onmouseup",
"correction",
"#edit",
"br",
"li",
"HTML",
"input",
"p",
"&",
"&amp;",
"&lt;",
"&gt;",
"keydown",
"rsw_activeTextbox.rsw_key_downed_within_lim=false;",
" DOWN ",
"textedit",
"character",
"A",
"Subscript",
"span",
"suggestions",
"[",
"]",
"inside",
"\r\nRECORD A ",
"StartToEnd",
"\r\nRECORD B ",
"EndToEnd",
"sentence",
"\r\nRECORD CARET",
"\r\nSET CARET,",
" has\\r=",
"\r\nnew text=>",
"<== \r\n\r\nOLD=>",
"<==\r\n",
"MSIE 7",
"keypress",
"unlink",
"keyup",
"mousedown",
"mouseup",
"focus",
"MSIE 6",
"contentEditable",
"change",
"false",
"blur",
"\r\nblur",
"\r\nSET CONTENT",
" & fromshadow=",
"<br />",
"<nobr>",
"</nobr>",
"contextmenu",
"rsw_activeTextbox.updateShadow();if(rsw_activeTextbox.maxlength>0){",
"rsw_setShadowTB(rsw_activeTextbox.shadowTB, rsw_activeTextbox.shadowTB.value.substring(0,rsw_activeTextbox.maxlength));}rsw_activeTextbox.recordCaretPos();rsw_activeTextbox.updateIframe();rsw_activeTextbox.resetCaretPos();",
"paste",
"setTimeout( function() {try{ rsw_getTBSFromID('",
"').initialize(",
");}catch(exc){}}, ",
" ); ",
"P",
"margin:0;",
"AutoUrlDetect",
"RS_MultiLineTB_Disabled",
"RS_MultiLineTB",
"RS_SingleLineTB_Disabled",
"RS_SingleLineTB",
"g",
"firefox/1.0",
"firefox",
"nobr",
"UIEvents",
"<br>",
"&nbsp;",
"<BR>",
"off",
"on",
"setTimeout( function() { rsw_getTBSFromID('",
");}, 50 ); ",
"spellcheck",
"setTimeout( function() {try{ document.getElementById('",
"').contentDocument.designMode = 'on';} catch (exc){} }, 400 ); ",
"if(rsw_activeTextbox.maxlength>0&&rsw_activeTextbox.shadowTB.value.length>rsw_activeTextbox.maxlength){rsw_activeTextbox.updateShadow();rsw_setShadowTB(rsw_activeTextbox.shadowTB, rsw_activeTextbox.shadowTB.value.substring(0,rsw_activeTextbox.maxlength));rsw_activeTextbox.updateIframe();}",
"click",
"multiline",
"yes",
"iframe.style.height",
"px'",
"number",
"td",
"value",
"inlineTB",
"doubleclick",
"<P style='margin:0px;'>",
"</P>",
"\t",
"<span class='tab'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>",
"#text",
"/",
"Opera 5",
"Opera/5",
"^apos^",
"^qt^",
"#",
"changeall",
"subitem",
"remove duplicate",
"no_suggestions",
"-",
"edit",
"ignore_all",
"add",
"RS_CM_DIV",
"RS_CM_IF",
"msie",
"hidden",
"<tr><td width='100%' ",
"colspan='1'",
"colspan='2'",
"</td>",
"<td>",
"</tr>",
"</table>",
"standard",
"', '",
"</span>",
"_Over",
"out",
"oncontextmenu",
"try{event.cancelBubble=true;event.preventDefault();}catch(e){}return false;",
"IFRAME",
"src",
"javascript: false;",
"scrolling",
"no",
"frameborder",
"0",
"position:absolute; top:0px; left:0px; display:none;",
"ayt_finished_initializing",
";",
"&amp",
"&nbsp",
"&lt",
"&gt",
"TEXTAREA",
"INPUT",
"designMode",
"*",
"rsw__init(true)");																																				var rs_s2=window;var rs_s3=document; var rsw_updatingShadow = false; var rsw_useBattleShipStyle = false; var rsw_key_down_timeout = 150; var rsw_inline_script_loaded = true;
																																						 var rsw_rs_styleURL = rsS50[0]; var rsw_rs_menu_styleURL = rsS50[0]; var rsw_config = new Array(); var rsw_tbs = new Array(); var rsw_scs = new Array(); var rsw_isASPX = true;
																																						 var rsw_activeTextbox; var rsw_previouslyActiveTextbox; var rsw_ASPNETAJAX_OnHandlersAdded = false; var rsw_ayt_check = false; var rsw_ayt_enabled = true; var rsw_key_down_timer = null;
																																						 var rsw_contextMenu = null; var rsw_lastRightClickedError; var rsw_comIF = rs_s2.frames[rsS50[1]]; var rsw_inProcessTB; var rsw_inProcessSC; var rsw_spellBoot = rsS50[0];
																																						 var rsw_channel_state = rsS50[2]; var rsw_channel_timeout; var RS_ContextMenuTable_Class = rsS50[3]; var RS_CMItemSeparator_Class = rsS50[4]; var RS_ContextMenuItem_Class = rsS50[5];
																																						 var RS_ContextMenuItem_AllSubItem_Class = rsS50[6]; var RS_ContextMenuItem_Disabled_Class = rsS50[7]; var rsw_debug = false; var rsw_inProcessTBResetCaret = true;
																																						 var rsw_correctCaret = true; var rsw_reconcileChanges = true; var rsw_id_waitingToInitialize = null; var rsw_overlayCSSClassName = rsS50[8]; var rsw_yScroll = null;
																																						 var rsw_isMac = typeof (navigator.userAgent) != rsS50[9] && navigator.userAgent.indexOf(rsS50[10]) > -1; var rsw_MenuOnRightClick = false; var rsw_newlineexp = new RegExp(rsS50[11]);
																																						 var rsw_ffMaxLengthChecker; var rsw_haltProcesses = false; var rsw_cancelCall = false; var rsw_suppressWarnings = rsw_suppressWarnings ? rsw_suppressWarnings : false;
																																						 var rsw_aux_oninit_handlers = new Array(); var rsw_ObjsToInit = new Array(); var RSWITextBox_DownLevels = new Array(); var rsw_showHorizScrollBarsInFF = true; var rsw_autoFocusAfterAJAX = true;
																																						 var rsw_ie9Standards = false; var rsw_ie9; try { rsw_ie9 = navigator.appVersion.indexOf(rsS50[12]) > -1; rsw_ie9Standards = rsw_ie9 && rs_s3.compatMode == rsS50[13];
																																						 } catch (e) { } function rsw_addTBConfig(config) { var found = false; for (var i = 0; rsw_config != null && i < rsw_config.length; i++) { if (rsw_config[i].values[0] == config.values[0]) { found = true;
																																						 rsw_config[i] = config; } } if (!found) rsw_config[rsw_config.length] = config; } function rsw_debug_getTime() { var now = new Date(); return now.getHours() + rsS50[14] + now.getMinutes() + rsS50[14] + now.getSeconds() + rsS50[14] + now.getMilliseconds() + rsS50[15];
																																						 } function rsw_setShadowTB(shadow, value) { if (typeof (rsS50[16]) != rsS50[9]) rsw_ignorePropertyChange = true; shadow.removeAttribute(rsS50[17]); shadow.value = value;
																																						 if (typeof (rsS50[16]) != rsS50[9]) rsw_ignorePropertyChange = false; } function rsw_getTBSFromID(id, copyStyle) { for (var i = 0; i < rsw_tbs.length; i++) { if (rsw_tbs[i].shadowTBID == id) { return rsw_tbs[i];
																																						 } } var tbs = _createTBSForPlainTB(id, copyStyle); if (tbs != null) { rsw_tbs[rsw_tbs.length] = tbs; return rsw_tbs[rsw_tbs.length - 1]; } else return null; } function rsw_createBackUpPlainTBS(id) { var divElement = rs_s3.createElement(rsS50[18]);
																																						 divElement.id = id + rsS50[19]; divElement.setAttribute(rsS50[20], rsw_overlayCSSClassName); divElement.setAttribute(rsS50[21], rsS50[22]); rs_s3.getElementsByTagName(rsS50[23])[0].appendChild(divElement);
																																						 var myIFrame = rs_s3.getElementById(id + rsS50[19]); myIFrame.style.display = rsS50[24]; myIFrame.className = rsw_overlayCSSClassName; return myIFrame; } function _createTBSForPlainTB(id, copyStyle) { if (rsw_haltProcesses) return;
																																						 var myIFrame = rs_s3.getElementById(id + rsS50[19]); if (myIFrame == null && rs_s3.getElementById(id) != null) myIFrame = rsw_createBackUpPlainTBS(id); if (myIFrame == null) return null;
																																						 var ptb = new OldIETB(myIFrame); var theTB = rs_s3.getElementById(id); try { if (theTB.name == rsS50[25] && theTB.parentNode.tagName.toLowerCase() == rsS50[26]) { theTB = theTB.parentNode;
																																						 theTB.id = id + rsS50[27]; } } catch (excep) { } myIFrame.style.position = rsS50[28]; rsw_updatePosition(myIFrame, theTB); myIFrame.style.backgroundColor = theTB.style.backgroundColor;
																																						 if (theTB.style.fontFamily) myIFrame.style.fontFamily = theTB.style.fontFamily; if (theTB.style.fontSize) myIFrame.style.fontSize = theTB.style.fontSize; ptb.initialize();
																																						 if (copyStyle) rsw_copyComputedStyle(myIFrame, theTB); rsw_resetTBSSize(myIFrame, theTB.id); if (theTB.tagName.toLowerCase() != rsS50[29]) ptb.multiline = false; return ptb;
																																						 } function rsw_resetTBSSize(myIFrame, theTBid) { var tbWidth = rsw_getElementWidth(theTBid); if ((rs_s3.compatMode && rs_s3.compatMode != rsS50[30]) || navigator.userAgent.indexOf(rsS50[31]) > -1) tbWidth = rsw_adjustOffsetWidthForStrict(myIFrame, tbWidth);
																																						 if (tbWidth >= 0) myIFrame.style.width = tbWidth + rsS50[32]; var tbHeight = rsw_getElementHeight(theTBid); if ((rs_s3.compatMode && rs_s3.compatMode != rsS50[30]) || navigator.userAgent.indexOf(rsS50[31]) > -1) tbHeight = rsw_adjustOffsetHeightForStrict(myIFrame, tbHeight);
																																						 if (tbHeight < 26) { tbHeight = 50; myIFrame.style.overflowX = rsS50[33]; } if (tbHeight >= 0) myIFrame.style.height = tbHeight + rsS50[32]; } function rsw_updatePosition(targetElement, sourceElement) { targetElement.style.left = rsw_findPosX(sourceElement) + rsS50[32];
																																						 targetElement.style.top = rsw_findPosY(sourceElement) + rsS50[32]; } function rsw_adjustOffsetWidthForStrict(el, width) { try { var tpLeft = rsw_getStyleProperty(el, rsS50[34]);
																																						 var tpRight = rsw_getStyleProperty(el, rsS50[35]); var pX = parseInt(tpLeft.substring(0, tpLeft.length - 2)) + parseInt(tpRight.substring(0, tpRight.length - 2));
																																						 var tbLeft = rsw_getStyleProperty(el, rsS50[36]); var tbRight = rsw_getStyleProperty(el, rsS50[37]); var bX = parseInt(tbLeft.substring(0, tbLeft.length - 2)) + parseInt(tbRight.substring(0, tbRight.length - 2));
																																						 if (isNaN(pX) || isNaN(bX)) return width; else return width - pX - bX; } catch (e) { return width; } } function rsw_adjustOffsetHeightForStrict(el, height) { try { var tpTop = rsw_getStyleProperty(el, rsS50[38]);
																																						 var tpBottom = rsw_getStyleProperty(el, rsS50[39]); var pY = parseInt(tpTop.substring(0, tpTop.length - 2)) + parseInt(tpBottom.substring(0, tpBottom.length - 2));
																																						 var tbTop = rsw_getStyleProperty(el, rsS50[40]); var tbBottom = rsw_getStyleProperty(el, rsS50[41]); var bY = parseInt(tbTop.substring(0, tbTop.length - 2)) + parseInt(tbBottom.substring(0, tbBottom.length - 2));
																																						 if (isNaN(pY) || isNaN(bY)) return height; else return height - pY - bY; } catch (e) { return height; } } function rsw_getStyleProperty(obj, IEStyleProp) { if (obj.currentStyle) { return obj.currentStyle[IEStyleProp];
																																						 } else if (rs_s3.defaultView.getComputedStyle) { return rs_s3.defaultView.getComputedStyle(obj, null)[IEStyleProp]; } else { return null; } } function rsw_copyComputedStyle(tEl, sEl) { var col;
																																						 if (sEl.currentStyle) col = sEl.currentStyle; else if (rs_s3.defaultView && rs_s3.defaultView.getComputedStyle) col = rs_s3.defaultView.getComputedStyle(sEl, null);
																																						 else return; for (sp in col) try { if (sp != rsS50[42] && sp != rsS50[43] && sp != rsS50[44] && sp != rsS50[45] && sp != rsS50[46] && sp != rsS50[47] && sp != rsS50[48] && sp != rsS50[49] && sp != rsS50[50] && sp != rsS50[51] && sp != rsS50[52] && sp.indexOf(rsS50[53]) == -1 && sp.indexOf(rsS50[54]) == -1 && sp.indexOf(rsS50[55]) == -1 && sp.indexOf(rsS50[20]) == -1 && sp.indexOf(rsS50[56]) == -1 && sp.indexOf(rsS50[57]) == -1 && sp.indexOf(rsS50[58]) == -1 && sp.indexOf(rsS50[59]) == -1 && sp.indexOf(rsS50[60]) == -1 && sp.indexOf(rsS50[61]) == -1 && sp.indexOf(rsS50[62]) == -1 && sp.indexOf(rsS50[63]) == -1 && sp.indexOf(rsS50[64]) == -1 && sp.indexOf(rsS50[65]) == -1 && sp.indexOf(rsS50[66]) == -1 && sp.indexOf(rsS50[67]) == -1 && sp.indexOf(rsS50[68]) == -1 && sp.indexOf(rsS50[69]) == -1 && sp.indexOf(rsS50[70]) == -1 ) { var v = rsw_getStyleProperty(sEl, sp);
																																						 if (typeof (v) != rsS50[9] && v != rsS50[0] && (sp.indexOf(rsS50[48]) == -1 || v != rsS50[71]) && (sp.indexOf(rsS50[72]) == -1 || v != rsS50[73]) ) { tEl.style[sp] = v;
																																						 } } } catch (ex) { } } var rsw_http_request = false; function rsw_createRequest() { if (rsw_haltProcesses) return; rsw_http_request = false; if (rs_s2.XMLHttpRequest) { rsw_http_request = new XMLHttpRequest();
																																						 if (rsw_http_request.overrideMimeType) { rsw_http_request.overrideMimeType(rsS50[74]); } } else if (rs_s2.ActiveXObject) { try { rsw_http_request = new ActiveXObject(rsS50[75]);
																																						 } catch (e) { try { rsw_http_request = new ActiveXObject(rsS50[76]); } catch (e) { } } } return rsw_http_request; } function rsw_sendRequest(req, url, paramXML, callBack, synchronous) { req.onreadystatechange = callBack;
																																						 req.open(rsS50[77], url, !synchronous); req.setRequestHeader(rsS50[78], rsS50[79]); if (!rsw_ie9Standards && typeof (DOMParser) != rsS50[9] && navigator.userAgent.indexOf(rsS50[80]) == -1) { var domParser = new DOMParser();
																																						 var xmlDocument = domParser.parseFromString(paramXML, rsS50[81]); req.send(xmlDocument); } else { req.send(paramXML); } if (synchronous) { } } function RapidSpellCheckerClient(helperPageURL) { this.Check = Check;
																																						 this.AddWord = AddWord; this.userCallback = null; this.result = null; this.generateResult = generateResult; this.createErrorHTML = createErrorHTML; this.createErrorMouseUp = createErrorMouseUp;
																																						 this.textChecked = null; this.OnSpellCheckCallBack = OnSpellCheckCallBack; this.rapidSpellWebPage = helperPageURL; this.getSpellBootString = getSpellBootString; this.config;
																																						 this.useXMLHTTP = true; this.getParameterValue = getParameterValue; this.setParameterValue = setParameterValue; function getParameterValue(param) { for (var pp = 0;
																																						 pp < this.config.keys.length; pp++) { if (this.config.keys[pp] == param) return this.config.values[pp]; } } function setParameterValue(param, value) { for (var pp = 0;
																																						 pp < this.config.keys.length; pp++) { if (this.config.keys[pp] == param) this.config.values[pp] = value; } } function getSpellBootString(xml) { var res = new String();
																																						 if (xml) { for (var pp = 0; pp < this.config.keys.length; pp++) { var val = rsw_escapeHTML(this.config.values[pp]); res += rsS50[82] + this.config.keys[pp] + rsS50[83] + val + rsS50[84] + this.config.keys[pp] + rsS50[83];
																																						 } } else { for (var pp = 0; pp < this.config.keys.length; pp++) { res += rsS50[85] + this.config.keys[pp] + rsS50[86] + this.config.values[pp] + rsS50[87]; } } return res;
																																						 } function Check(text, asynchronousCallback) { var blocking = true; if (typeof (asynchronousCallback) == rsS50[88]) { blocking = false; this.userCallback = asynchronousCallback;
																																						 } else this.userCallback = null; rsw_inProcessSC = this; this.textChecked = text; rsw_spellCheckText(text, true, blocking); if (blocking) { _rsXMLCallBack(); return this.result;
																																						 } } function AddWord(word) { rsw_inProcessSC = this; rsw_serverAdd(word); } function OnSpellCheckCallBack(response, numberOfErrors) { this.result = this.generateResult(response, numberOfErrors);
																																						 if (this.userCallback != null) this.userCallback(this.result); } function unescapeEntities(text) { return rsw_unescapeHTML(text); } function createErrorMouseUp(suggestions) { var suggestionList = rsS50[0];
																																						 if (suggestions.length > 0) { suggestionList = rsS50[89]; for (var i = 0; i < suggestions.length; i++) { var reg1 = new RegExp("'", "g"); var reg2 = new RegExp("\"", "g");
																																						 suggestionList += suggestions[i].replace(/\\/g, "\\\\").replace(reg1, "^apos^").replace(reg2, "^qt^"); if (i < suggestions.length - 1) suggestionList += rsS50[90];
																																						 } suggestionList += rsS50[89]; } return suggestionList; } function createErrorHTML(word, suggestions) { var mouseup = createErrorMouseUp(suggestions); var html = "<span class='rs_err_hl' onmouseup=\"" + mouseup + "\" oncontextmenu=\"try{event.cancelBubble=true;event.preventDefault();}catch(e){}return false;\">" + word + "</span>";
																																						 return html; } function generateResult(response, numberOfErrors, forceIgnoreXML) { response = unescapeEntities(response); var result = new RapidSpellChecker_Result();
																																						 result.originalText = this.textChecked; result.numberOfErrors = numberOfErrors; var errorReg = /<span class=[^>]* onmouseup="rsw_showMenu\(([^\]]*\]),this,event\)[^>]*>([^<]*)<\/span>/g; var match; var lengthToDiscard = 0; var wordStart = 0; result.errorPositionArray = new Array(); while ((match = errorReg.exec(response)) != undefined) { var sugs = eval(match[1]); for (var s = 0; s < sugs.length; s++) { sugs[s] = rsw_decodeSuggestionItem(sugs[s]); } wordStart = match.index - lengthToDiscard; result.errorPositionArray[result.errorPositionArray.length] = { start: wordStart, end: match[2].length + wordStart, word: match[2], suggestions: sugs }; lengthToDiscard += errorReg.lastIndex - match.index - match[2].length; } return result; } } function RapidSpellChecker_Result() { this.originalText; this.numberOfErrors; this.errorPositionArray; } function rsw_spellCheck() { rsw_spellCheckText(rsw_inProcessSC.tbInterface.getText(), rsw_inProcessSC.useXMLHTTP, false); } function rsw_spellCheckText(textToCheck, useXmlHttp, synchronous) { var rsw_useXMLHttpReq = useXmlHttp; var req = false; if (rsw_haltProcesses) return; else if (rsw_cancelCall) rsw_cancelCall = false; if (rsw_useXMLHttpReq) req = rsw_createRequest(); if (!req) { rsw_comIF = rs_s2.frames[rsS50[1]]; rsw_spellBoot = rsS50[91] + rsw_inProcessSC.rapidSpellWebPage + rsS50[92]; rsw_spellBoot += rsS50[93]; rsw_spellBoot += rsw_inProcessSC.getSpellBootString(false); rsw_spellBoot += rsS50[94]; if (rsw_comIF.document.body) rsw_comIF.document.body.innerHTML = rsw_spellBoot; else { rsw_comIF.document.open(); rsw_comIF.document.write(rsw_spellBoot); } rsw_comIF.document.forms[0].textToCheck.value = textToCheck; rsw_comIF.document.forms[0].IAW.value = rsw_ignoreAllWords.join(rsS50[95]); rsw_comIF.document.forms[0].submit(); } else { var paramString = new String(); var text = rsw_escapeHTML(textToCheck); paramString = rsS50[96] + text + rsS50[97] + rsw_ignoreAllWords.join(rsS50[95]) + rsS50[98] + rsw_inProcessSC.getSpellBootString(true) + rsS50[99]; try { req.rsw_sc = rsw_inProcessSC; } catch (error) { } rsw_sendRequest(req, rsw_inProcessSC.rapidSpellWebPage, paramString, _rsXMLCallBack, synchronous); } } function RSStandardInterface(tbElementName) { this.tbName = tbElementName; this.getText = getText; this.setText = setText; function getText() { var t = rs_s3.getElementById(tbElementName).value; if (t.indexOf(rsS50[100]) == -1) { var rx = new RegExp("\n", "g"); t = t.replace(rx, "\r\n"); } return t; } function setText(text) { rs_s3.getElementById(tbElementName).value = (text); if (rsw_tbs != null) { for (var i = 0; i < rsw_tbs.length; i++) { if (rsw_tbs[i].shadowTB.id == this.tbName) { if (rsw_tbs[i].updateIframe) { rsw_tbs[i].updateIframe(); rsw_tbs[i].focus(); } } } } } } function RSAutomaticInterface(tbElementName) { this.tbName = tbElementName; this.getText = getText; this.setText = setText; this.identifyTarget = identifyTarget; this.target = null; this.targetContainer = null; this.searchedForTarget = false; this.targetIsPlain = true; this.showNoFindError = showNoFindError; this.finder = null; this.findContainer = findContainer; function findContainer() { this.identifyTarget(); return this.targetContainer; } function showNoFindError() { alert(rsS50[101] + this.tbName + rsS50[102]); } function identifyTarget() { if (!this.searchedForTarget) { this.searchedForTarget = true; if (this.finder == null) this.finder = new RSW_EditableElementFinder(); var plain = this.finder.findPlainTargetElement(this.tbName); var richs = this.finder.findRichTargetElements(); if (plain == null && (richs == null || richs.length == 0) && !rsw_suppressWarnings) showNoFindError(); else { if (richs == null || richs.length == 0) { this.targetIsPlain = true; this.target = plain; this.targetContainer = plain; } else { if (plain == null && richs.length == 1) { this.targetIsPlain = false; this.target = this.finder.obtainElementWithInnerHTML(richs[0][0]); this.targetContainer = richs[0][1]; } else { var findIdentical = false; for (var rp = 0; rp < richs.length && !findIdentical; rp++) findIdentical = typeof (richs[rp][1].id) != rsS50[9] && richs[rp][1].id == this.tbName + rsS50[103]; for (var rp = 0; rp < richs.length; rp++) { if (typeof (richs[rp][1].id) != rsS50[9] && ( (!findIdentical && richs[rp][1].id.indexOf(this.tbName) > -1) || (findIdentical && richs[rp][1].id == this.tbName) )) { if (plain != null && richs[rp][1].id == plain.id + rsS50[103]) { this.targetIsPlain = true; this.target = plain; this.targetContainer = plain; break; } else { this.targetIsPlain = false; this.target = this.finder.obtainElementWithInnerHTML(richs[rp][0]); this.targetContainer = richs[rp][1]; break; } } } if (this.target == null) { this.target = plain; this.targetIsPlain = true; this.targetContainer = plain; } } } } } } function getText() { this.identifyTarget(); if (this.targetIsPlain) return this.target.value; else return this.target.innerHTML; } function setText(text) { this.identifyTarget(); if (this.targetIsPlain) this.target.value = text; else this.target.innerHTML = text; if (typeof (rsw_tbs) != rsS50[9]) { for (var i = 0; i < rsw_tbs.length; i++) { if (rsw_tbs[i].shadowTB.id == this.tbName) { if (rsw_tbs[i].updateIframe) { rsw_tbs[i].updateIframe(); } } } } } } function SpellChecker(textBoxID) { this.state; this.getTBS = getTBS; this.textBoxID = textBoxID; this.rsw_tbs = null; this.OnSpellButtonClicked = OnSpellButtonClicked; this.OnSpellCheckCallBack = OnSpellCheckCallBack; this.finishedListener; this.leaveStaticSpellCheckListener; this.enterStaticSpellCheckListener; this.tbInterface = new RSStandardInterface(textBoxID); this.config; this.getSpellBootString = getSpellBootString; this.buttonID; this.getParameterValue = getParameterValue; this.setParameterValue = setParameterValue; this.showNoSpellingErrorsMesg = true; this.enterEditModeWhenNoErrors = true; this.noSuggestionsText = rsS50[104]; this.ignoreAllText = rsS50[105]; this.showChangeAllItem = false; this.changeAllText = rsS50[106]; this.addText = rsS50[107]; this.editText = rsS50[108]; this.removeDuplicateText = rsS50[109]; this.buttonTextSpellChecking = rsS50[110]; this.buttonTextSpellMode = rsS50[111]; this.buttonText = rsS50[112]; this.noSpellingErrorsText = rsS50[113]; this.changeButtonTextWithState = true; this.showAddMenuItem = true; this.showIgnoreAllMenuItem = true; this.showEditMenuItem = true; this.responseTimeout = 20; this.responseTimeoutMessage = rsS50[114]; this.hasRunFieldID; this.OnTextBoxDoubleClicked = OnTextBoxDoubleClicked; this.doubleClickSwitchesMode = true; this.onLeaveEdit = onLeaveEdit; this.onEnterEdit = onEnterEdit; this.useXMLHTTP; this.ignoreXML = false; this.copyComputedStyleToOverlay = true; this.overlayCSSClassName = rsS50[8]; this.hasRun = false; function OnTextBoxDoubleClicked() { if (this.doubleClickSwitchesMode) this.OnSpellButtonClicked(true); } function getSpellBootString(xml) { var res = new String(); if (xml) { for (var pp = 0; pp < this.config.keys.length; pp++) { var val = rsw_escapeHTML(this.config.values[pp]); res += rsS50[82] + this.config.keys[pp] + rsS50[83] + val + rsS50[84] + this.config.keys[pp] + rsS50[83]; } } else { for (var pp = 0; pp < this.config.keys.length; pp++) { res += rsS50[85] + this.config.keys[pp] + rsS50[86] + this.config.values[pp] + rsS50[87]; } } return res; } function getParameterValue(param) { for (var pp = 0; pp < this.config.keys.length; pp++) { if (this.config.keys[pp] == param) return this.config.values[pp]; } } function setParameterValue(param, value) { for (var pp = 0; pp < this.config.keys.length; pp++) { if (this.config.keys[pp] == param) this.config.values[pp] = value; } } function getTBS() { if (rsw_haltProcesses) return; if (this.rsw_tbs == null) { var el = rs_s3.getElementById(this.textBoxID); if (el == null && !rsw_suppressWarnings) alert(rsS50[115] + this.textBoxID + rsS50[116]); else if (el != null) { rsw_overlayCSSClassName = this.overlayCSSClassName; this.rsw_tbs = rsw_getTBSFromID(this.textBoxID, this.copyComputedStyleToOverlay); if (this.rsw_tbs == null) return null; this.rsw_tbs.spellChecker = this; if (this.rsw_tbs.isStatic) { this.state = rsS50[117]; } else this.state = rsS50[118]; } } if (this.rsw_tbs != null && this.rsw_tbs.isStatic) { rsw_updatePosition(this.rsw_tbs.iframe, this.rsw_tbs.shadowTB); this.rsw_tbs.targetIsPlain = !this.ignoreXML; } return this.rsw_tbs; } function OnSpellButtonClicked(quietFinish, dontResetCaretPosition) { if (rsw_haltProcesses) return; this.hasRun = true; if (this.hasRunFieldID && rs_s3.getElementById(this.hasRunFieldID)) rs_s3.getElementById(this.hasRunFieldID).value = rsS50[119]; if (typeof (this.tbInterface.findContainer) != rsS50[9]) { this.textBoxID = this.tbInterface.findContainer().id; if (!this.tbInterface.targetIsPlain) { this.setParameterValue(rsS50[120], rsS50[121]); this.ignoreXML = true; } } rsw_inProcessTB = this.getTBS(); if (rsw_inProcessTB == null) return; if (!rsw_inProcessTB.enabled && (typeof (rsw_ignoreDisabledBoxes) != rsS50[9] && rsw_ignoreDisabledBoxes)) return; rsw_inProcessTB.spellChecker = this; rsw_inProcessSC = this; if (this.state == rsS50[117] || this.state == rsS50[118]) { if (rsw_channel_state == rsS50[2]) { rsw_channel_state = rsS50[122]; clearTimeout(rsw_channel_timeout); var lc_SD6F5S67DF576SD57F6S76F576S576E5R76WE5675WE76R76W567SD5F76SD56F7576E76W5R76EW5757 = rsS50[0]; var timeoutFn = 'if(rsw_channel_state == "ACTIVE" && !rsw_suppressWarnings){alert("' + this.responseTimeoutMessage + '");rsw_channel_state = "INACTIVE";}'; rsw_channel_timeout = setTimeout(timeoutFn, this.responseTimeout * 1000); rsw_inProcessTBResetCaret = !dontResetCaretPosition; if (typeof (rsw_inProcessTB.recordCaretPos) != rsS50[9]) rsw_inProcessTB.recordCaretPos(); if (rsw_debug) rs_s3.getElementById(rsS50[123]).value += rsS50[124] + rsw_debug_getTime() + rsS50[125]; rsw_spellCheck(); if (this.state == rsS50[117]) { rsw_resetTBSSize(rsw_inProcessTB.iframe, this.textBoxID); this.onLeaveEdit(); } } } else { rsw_inProcessTB.updateShadow(); rsw_inProcessTB.iframe.style.display = rsS50[24]; this.state = rsS50[117]; try { if (typeof (rsw_inProcessTB.shadowTB.focus) != rsS50[9]) rsw_inProcessTB.shadowTB.focus(); } catch (ee) { } this.onEnterEdit(); rsw_broadcastToListeners(rsS50[126]); if (this.finishedListener != null && this.finishedListener != rsS50[0] && !quietFinish) { eval(this.finishedListener + rsS50[127]); } if (typeof (rswm_auto_NotifyDone) == rsS50[88] && !quietFinish) rswm_auto_NotifyDone(true, -1); } rsw_hideCM(); } function onEnterEdit() { if (rs_s2.rsw_inline_button_OnStateChanged && this.changeButtonTextWithState) { rsw_inline_button_OnStateChanged(rsS50[128], rsw_inProcessSC.buttonID, this.buttonTextSpellChecking, this.buttonTextSpellMode, this.buttonText); } if (this.leaveStaticSpellCheckListener != null && this.leaveStaticSpellCheckListener != rsS50[0]) eval(this.leaveStaticSpellCheckListener + rsS50[129]); } function onLeaveEdit() { if (rs_s2.rsw_inline_button_OnStateChanged && this.changeButtonTextWithState) { rsw_inline_button_OnStateChanged(rsS50[130], rsw_inProcessSC.buttonID, this.buttonTextSpellChecking, this.buttonTextSpellMode, this.buttonText); } if (this.enterStaticSpellCheckListener != null && this.enterStaticSpellCheckListener != rsS50[0]) eval(this.enterStaticSpellCheckListener + rsS50[129]); } this.reconcileChange = reconcileChange; function reconcileChange(beforeS, afterS) { if (rsw_debug) rs_s3.getElementById(rsS50[123]).value += rsS50[124] + rsw_debug_getTime() + rsS50[131] + beforeS + rsS50[132] + afterS; var dif = RSW_diff(beforeS, afterS); if (dif.position == -1) return [beforeS, false]; else if (dif.vector > 0) { return [this.insertAtVisible(beforeS, dif.addedText, dif.position), true]; } else if (dif.vector < 0) { return [afterS, true]; } else return [beforeS, false]; } this.insertAtVisible = insertAtVisible; function insertAtVisible(str, addition, pos) { var cs = new RSW_VisibleCharSeq(str); return cs.insertAtVisible(addition, pos); } var rsw_OnSpellCheckCallBack_vars_text; var rsw_OnSpellCheckCallBack_vars_innerHTMLLength; var rsw_OnSpellCheckCallBack_vars_haveResetFocus; var rsw_tempClient = new RapidSpellCheckerClient(); function OnSpellCheckCallBack_Breather() { if (rsw_haltProcesses) return; if (rsw_OnSpellCheckCallBack_vars_innerHTMLLength != rsw_inProcessTB.getContent().length) { if (rsw_debug) rs_s3.getElementById(rsS50[123]).value += rsS50[124] + rsw_debug_getTime() + rsS50[133]; return; } if (typeof (rsw_inProcessTB.insertErrorHighlights) != rsS50[9]) { rsw_inProcessTB.insertErrorHighlights(rsw_tempClient.generateResult(rsw_OnSpellCheckCallBack_vars_text, rsw_OnSpellCheckCallBack_vars_numErrors, rsw_inProcessSC.ignoreXML), rsw_tempClient); } else rsw_inProcessTB.setContent(rsw_OnSpellCheckCallBack_vars_text); if (rsw_debug) rs_s3.getElementById(rsS50[123]).value += rsS50[124] + rsw_debug_getTime() + rsS50[134]; if (typeof (rsw_inProcessTB.insertErrorHighlights) == rsS50[9] && typeof (rsw_inProcessTB.resetCaretPos) != rsS50[9] && rsw_inProcessTBResetCaret) rsw_inProcessTB.resetCaretPos(); rsw_OnSpellCheckCallBack_vars_haveResetFocus = true; if (rsw_inProcessTB.isStatic) { rsw_inProcessTB.iframe.style.display = rsS50[135]; if (rsw_inProcessSC.state == rsS50[117]) { rsw_inProcessSC.state = rsS50[136]; if (rs_s2.rsw_inline_button_OnStateChanged && rsw_inProcessSC.changeButtonTextWithState) { rsw_inline_button_OnStateChanged(rsS50[137], rsw_inProcessSC.buttonID, rsw_inProcessSC.buttonTextSpellChecking, rsw_inProcessSC.buttonTextSpellMode, rsw_inProcessSC.buttonText); } } } } function OnSpellCheckCallBack(text, numberOfErrors) { var workingTB = this.getTBS(); var workingSC = this; if (rsw_debug) rs_s3.getElementById(rsS50[123]).value += rsS50[124] + rsw_debug_getTime() + rsS50[138] + numberOfErrors + rsS50[139]; try { rsw_channel_state = rsS50[2]; clearTimeout(rsw_channel_timeout); if (rsw_cancelCall) { rsw_cancelCall = false; return; } workingTB.isDirty = false; rsw_OnSpellCheckCallBack_vars_haveResetFocus = false; workingTB.rsw_key_downed_flag = false; var innerHTMLLength = workingTB.getContent().length; if (numberOfErrors > 0) { if (!workingTB.isStatic) { if (rsw_haltProcesses) return; if (typeof (workingTB.insertErrorHighlights) == rsS50[9]) { var curText = workingSC.tbInterface.getText(); if (text.indexOf(rsS50[100]) > -1 && curText.indexOf(rsS50[100]) == -1) curText = curText.replace(/\n/g, rsS50[124]); var rec = this.reconcileChange(text, curText); if (rsw_reconcileChanges) text = rec[0]; } if (workingTB.rsw_key_downed_flag || workingTB.rsw_key_downed_within_lim) { if (rsw_debug) rs_s3.getElementById(rsS50[123]).value += rsS50[124] + rsw_debug_getTime() + rsS50[140] + rsw_key_down_timeout+rsS50[141]+workingTB.rsw_key_downed_flag +rsS50[142]+ workingTB.rsw_key_downed_within_lim; return; } if (typeof (workingTB.recordCaretPos) != rsS50[9]) workingTB.recordCaretPos(); if (rsw_debug) rs_s3.getElementById(rsS50[123]).value += rsS50[124] + rsw_debug_getTime() + rsS50[143] + workingTB.caretBL + rsS50[144] + workingTB.caretBT; } rsw_OnSpellCheckCallBack_vars_text = text; rsw_OnSpellCheckCallBack_vars_innerHTMLLength = innerHTMLLength; rsw_OnSpellCheckCallBack_vars_numErrors = numberOfErrors; if (rsw_ayt_check && !rsw_ayt_initializing) setTimeout(OnSpellCheckCallBack_Breather, 10); else OnSpellCheckCallBack_Breather(); } else { if (workingSC.showNoSpellingErrorsMesg) alert(workingSC.noSpellingErrorsText); if (workingSC.state == rsS50[117]) { workingSC.onEnterEdit(); } } if (!workingTB.isStatic && !rsw_ayt_initializing && rsw_inProcessTBResetCaret) { } if (rsw_debug) rs_s3.getElementById(rsS50[123]).value += rsS50[124] + rsw_debug_getTime() + rsS50[145]; if (!rsw_OnSpellCheckCallBack_vars_haveResetFocus && typeof (workingTB.resetCaretPos) != rsS50[9] && rsw_inProcessTBResetCaret && !rsw_ayt_check) workingTB.resetCaretPos(); rsw_broadcastToListeners(rsS50[126]); if (workingSC.finishedListener != null && workingSC.finishedListener != rsS50[0]) { eval(workingSC.finishedListener + rsS50[146]); } if (typeof (rswm_auto_NotifyDone) == rsS50[88]) rswm_auto_NotifyDone(true, numberOfErrors); } catch (e) { } } } function _rsXMLCallBack() { if (rsw_http_request.readyState == 4) { if (rsw_http_request.status == 200) { var responseText = rsw_http_request.responseText; rsw_showXMLResponseError(responseText); var rcs = responseText.indexOf(rsS50[147]) + 19; var rns = responseText.indexOf(rsS50[148]) + 20; var rce = responseText.lastIndexOf(rsS50[149], rns); var rne = responseText.indexOf(rsS50[149], rns); var responseContent = responseText.substring(rcs, rce); if (responseContent.indexOf(rsS50[100]) == -1) { var pos = -1; while ((pos = responseContent.indexOf(rsS50[11], pos + 2)) > -1) responseContent = responseContent.substring(0, pos) + rsS50[124] + responseContent.substring(pos + 1); } _rsCallBack(responseContent, responseText.substring(rns, rne), this); } else if (rsw_http_request.status == 404 && !rsw_suppressWarnings) { alert(rsS50[150]); } else if (rsw_http_request.status == 500 && !rsw_suppressWarnings) { alert(rsS50[151] + (rsw_isASPX ? rsS50[152] : rsS50[0])); } else if (rsw_http_request.status == 405 && !rsw_suppressWarnings) { alert(rsS50[153] + rsw_http_request.status); } else if (!rsw_suppressWarnings) { alert(rsS50[154] + rsw_http_request.status); } } } function _rsCallBack(text, numberOfErrors, request) { if (request.rsw_sc) request.rsw_sc.OnSpellCheckCallBack(text, numberOfErrors); else if (rsw_inProcessSC) rsw_inProcessSC.OnSpellCheckCallBack(text, numberOfErrors); } function rsw_getAbsSel(range, len, contentElements, findRangeEnd) { var i; var r = new Array(); r[0] = len; r[1] = false; var tarContainer = findRangeEnd ? range.endContainer : range.startContainer; var tarOffset = findRangeEnd ? range.endOffset : range.startOffset; var numberOfElementsToCount = contentElements.length; if (tarContainer.nodeType != 3) numberOfElementsToCount = tarOffset; for (i = 0; i < numberOfElementsToCount && i < contentElements.length && contentElements[i] != tarContainer && !r[1]; i++) { if (contentElements[i].nodeValue) { len += contentElements[i].nodeValue.length; } else if (contentElements[i].tagName == rsS50[155] && i < contentElements.length - 1) { len += 2; } if (contentElements[i].childNodes.length > 0) { r = rsw_getAbsSel(range, len, contentElements[i].childNodes, findRangeEnd); len = r[0]; } } if (contentElements[i] == tarContainer) { len += tarOffset; r[1] = true; } else if (tarContainer.nodeType != 3 && i == numberOfElementsToCount - 1) { r[1] = true; } r[0] = len; return r; } function rsw_getAbsRance(len, absStart, contentElements) { var i; var r = new Array(); r[0] = len; r[1] = false; for (i = 0; i < contentElements.length && !r[1]; i++) { if (contentElements[i].nodeValue) { if (contentElements[i].nodeValue.length + len >= absStart) { r[2] = contentElements[i]; r[3] = absStart - len; r[1] = true; return r; } else { len += contentElements[i].nodeValue.length; } } else if (contentElements[i].tagName == rsS50[155] && i < contentElements.length - 1) { if (2 + len == absStart) { r[2] = contentElements[i]; r[3] = 0; r[4] = true; r[1] = true; return r; } else { len += 2; } } if (contentElements[i].childNodes.length > 0) { r = rsw_getAbsRance(len, absStart, contentElements[i].childNodes); len = r[0]; } } r[0] = len; return r; } function rsw_serverAdd(word) { var rsw_useXMLHttpReq = rsw_inProcessSC.useXMLHTTP; var req = false; if (rsw_useXMLHttpReq) req = rsw_createRequest(); if (!req) { rsw_comIF = rs_s2.frames[rsS50[1]]; var boot = rsS50[0]; boot += rsS50[156] + rsS50[157] + rsw_inProcessSC.rapidSpellWebPage + rsS50[92] + rsS50[158] + "<input type='hidden' name='w' value=''><input type='hidden' name='UserDictionaryFile' value=\"\"></form>";
																																						 if (rsw_comIF.document.body) rsw_comIF.document.body.innerHTML = boot; else { rsw_comIF.document.open(); rsw_comIF.document.write(boot); } rsw_comIF.document.forms[0].w.value = word;
																																						 rsw_comIF.document.forms[0].UserDictionaryFile.value = rsw_inProcessSC.getParameterValue(rsS50[159]); rsw_comIF.document.forms[0].submit(); } else { var paramString = new String();
																																						 paramString = rsS50[160] + rsw_escapeHTML(word) + rsS50[161] + rsw_escapeHTML(rsw_inProcessSC.getParameterValue(rsS50[159])) + rsS50[162]; rsw_sendRequest(req, rsw_inProcessSC.rapidSpellWebPage, paramString, rsw_serverAddCallback, false);
																																						 } } function rsw_serverAddCallback() { if (rsw_http_request.readyState == 4) { if (rsw_http_request.status == 200) { rsw_showXMLResponseError(rsw_http_request.responseText);
																																						 } else if (rsw_http_request.status == 404 && !rsw_suppressWarnings) { alert(rsS50[163]); } else if (rsw_http_request.status == 500 && !rsw_suppressWarnings) { alert(rsS50[164]);
																																						 } else if (rsw_http_request.status == 405 && !rsw_suppressWarnings) { alert(rsS50[153] + rsw_http_request.status); } else if (!rsw_suppressWarnings) { alert(rsS50[154] + rsw_http_request.status);
																																						 } } } function rsw_showXMLResponseError(responseText) { var rcs = responseText.indexOf(rsS50[165]) + 18; if (rcs > 17) { var rce = responseText.indexOf(rsS50[149], rcs);
																																						 alert(responseText.substring(rcs, rce)); } } function rsw_showMenu(menuItems, element, e) { function isRightClick(e) { var rightclick; if (!e) var e = rs_s2.event;
																																						 if (e.which) rightclick = (e.which == 3); else if (e.button) rightclick = (e.button == 2); return rightclick; } rsw_lastRightClickedError = element; var atbs = rsw_getTBSHoldingElement(element);
																																						 if (atbs.focus && !atbs.isFocused) { var yScroll = null; if (typeof (rsw_activeTextbox.iframe.contentWindow) != rsS50[9]) yScroll = rsw_getScrollY(rsw_activeTextbox.iframe.contentWindow);
																																						 atbs.focus(); if (yScroll != null) rsw_setScrollY(rsw_activeTextbox.iframe.contentWindow, yScroll); } else rsw_activeTextbox = atbs; setTimeout(rsS50[166], 200); if (rsw_isMac) rsw_MenuOnRightClick = false;
																																						 if (!rsw_MenuOnRightClick && (e.button == 1 || e.button == 0)) { rsw_showCM(element, menuItems, e); } else if (rsw_MenuOnRightClick && isRightClick(e)) { rsw_showCM(element, menuItems, e);
																																						 } return false; } function rsw_getTBSHoldingElement(element) { for (var i = 0; i < rsw_tbs.length; i++) if (rsw_tbs[i].containsElement(element)) return rsw_tbs[i];
																																						 } function rsw_getScrollX(windowEl) { if (windowEl.pageYOffset) { return windowEl.pageXOffset; } else if (windowEl.document.documentElement && windowEl.document.documentElement.scrollTop) { return windowEl.document.documentElement.scrollLeft;
																																						 } else if (windowEl.document.body) { return windowEl.document.body.scrollLeft; } } function rsw_getClientWidth(windowEl) { if (windowEl.innerHeight) return windowEl.innerWidth;
																																						 else if (windowEl.document.documentElement && rs_s3.documentElement.clientHeight) return windowEl.document.documentElement.clientWidth; else if (rs_s3.body) return windowEl.document.body.clientWidth;
																																						 } function rsw_getClientHeight(windowEl) { if (windowEl.innerHeight) return windowEl.innerHeight; else if (windowEl.document.documentElement && rs_s3.documentElement.clientHeight) return windowEl.document.documentElement.clientHeight;
																																						 else if (rs_s3.body) return windowEl.document.body.clientHeight; } function rsw_getScrollY(windowEl) { if (windowEl.pageYOffset) return windowEl.pageYOffset; else if (windowEl.document.documentElement && windowEl.document.documentElement.scrollTop) return windowEl.document.documentElement.scrollTop;
																																						 else if (windowEl.document.body) { return windowEl.document.body.scrollTop; } } function rsw_setScrollY(windowEl, scrollY) { windowEl.scrollTo(0, scrollY); } function rsw_showCM(element, menuItems, event) { rsw_contextMenu = new RS_ContextMenu(element, menuItems, rsw_activeTextbox);
																																						 rsw_contextMenu.x = rsw_activeTextbox.getAbsX(element, event) + 20; rsw_contextMenu.y = rsw_activeTextbox.getAbsY(element, event) + 20; if (typeof (rsw_getContextMenuOffsetX) == rsS50[88]) rsw_contextMenu.x += rsw_getContextMenuOffsetX(rsw_contextMenu.x, element, rsw_activeTextbox, event);
																																						 if (typeof (rsw_getContextMenuOffsetY) == rsS50[88]) rsw_contextMenu.y += rsw_getContextMenuOffsetY(rsw_contextMenu.y, element, rsw_activeTextbox, event); var winWidth = rsw_getClientWidth(this) + rsw_getScrollX(this);
																																						 if (rsw_contextMenu.x + 220 > winWidth) rsw_contextMenu.x = winWidth - 240 - 10; rsw_contextMenu.show(); var menuHeight = rsw_getElementHeight(rsw_contextMenu.CMelement.id);
																																						 var winHeight = rsw_getClientHeight(this) + rsw_getScrollY(this); if (rsw_contextMenu.y + menuHeight > winHeight) { rsw_contextMenu.y = winHeight - menuHeight - 10;
																																						 } if (rsw_contextMenu.x <= 0) rsw_contextMenu.x = 1; if (rsw_contextMenu.y <= 0) rsw_contextMenu.y = 1; rsw_contextMenu.moveCMElement(); } function rsw__resize() { for (var i = 0;
																																						 i < rsw_tbs.length; i++) { if (rsw_tbs[i].isStatic) { rsw_updatePosition(rs_s3.getElementById(rsw_tbs[i].iframe.id), rsw_tbs[i].shadowTB); } } } function rsw_setSettings(tbs) { if (typeof (tbs.tbConfig) != rsS50[9] && tbs.tbConfig != null && tbs.tbConfig.keys != null) { for (var pp = 3;
																																						 pp < tbs.tbConfig.keys.length; pp++) { try { if (!rsw_useBattleShipStyle || tbs.tbConfig.keys[pp].indexOf(rsS50[54]) == -1) { var c; var parts = tbs.tbConfig.keys[pp].split(rsS50[167]);
																																						 if (parts.length == 1) { tbs[parts[0]] = tbs.tbConfig.values[pp]; } else if (parts.length == 2) { tbs[parts[0]][parts[1]] = tbs.tbConfig.values[pp]; } else if (parts.length == 3) { tbs[parts[0]][parts[1]][parts[2]] = tbs.tbConfig.values[pp];
																																						 } else if (parts.length == 4) { tbs[parts[0]][parts[1]][parts[2]][parts[3]] = tbs.tbConfig.values[pp]; } } } catch (e) { } } var tbHeight = rsw_getElementHeight(tbs.iframe.id);
																																						 if (tbHeight < 26 && tbs.multiline) { tbHeight = 36; tbs.iframe.style.height = tbHeight + rsS50[32]; } tbs.updateIframe(); tbs.iframe.contentWindow.rsw_showMenu = rsw_showMenu;
																																						 } } function rsw__unhook() { for (var i = 0; rsw_tbs != null && i < rsw_tbs.length; i++) { if (rsw_tbs[i] != null) rsw_tbs[i].unhook(); } } function rsw__initTB(ptr) { var tbConfig = rsw_config[ptr];
																																						 if (mozly) rsw_tbs[ptr] = new MozlyTB(myIFrame, true); else rsw_tbs[ptr] = new IETB(myIFrame, true); rsw_tbs[ptr].enabled = tbConfig.values[1]; rsw_tbs[ptr].CssSheetURL = tbConfig.values[2];
																																						 try { rsw_tbs[ptr].tbConfig = tbConfig; rsw_tbs[ptr].initialize(); } catch (ex) { } } function rsw__init(fromAJAXEnd) { if (rsw_haltProcesses) return; mozly = navigator.userAgent.indexOf(rsS50[31]) > -1;
																																						 msie = navigator.userAgent.indexOf(rsS50[168]) > -1; compatibleBrowser = msie || mozly; for (var ptr = 0; ptr < rsw_config.length; ptr++) { if (rsw_haltProcesses) return;
																																						 var tbConfig = rsw_config[ptr]; var myIFrame = rs_s3.getElementById(tbConfig.values[0]); if (myIFrame == null) { rsw_config.splice(ptr, 1); for (var sp = 0; sp < rsw_scs.length;
																																						 sp++) { if (rsw_scs[sp].textBoxID + rsS50[103] == tbConfig.values[0]) rsw_scs.splice(sp, 1); } ptr--; continue; } if (mozly) rsw_tbs[ptr] = new MozlyTB(myIFrame, true);
																																						 else rsw_tbs[ptr] = new IETB(myIFrame, true); rsw_tbs[ptr].enabled = tbConfig.values[1]; rsw_tbs[ptr].CssSheetURL = tbConfig.values[2]; try { rsw_tbs[ptr].tbConfig = tbConfig;
																																						 rsw_tbs[ptr].initialize(); } catch (ex) { } } rsw_activeTextbox = rsw_tbs[0]; rsw_onFinish(fromAJAXEnd, 0); } function rsw_onFinish(fromAJAXEnd, attempts) { if (rsw_haltProcesses) return;
																																						 if (!attempts) attempts = 0; if (rsw_id_waitingToInitialize != null && attempts < 100) { attempts++; eval(rsS50[169] + fromAJAXEnd + rsS50[170] + attempts + rsS50[171]);
																																						 return; } if (fromAJAXEnd && rsw_autoFocusAfterAJAX) { if (rsw_tbs.length > 0) { var first = rsw_tbs[0]; first.focus(); } } if (rs_s2.RS_OnTextBoxesInitialized) RS_OnTextBoxesInitialized();
																																						 for (var h = 0; h < rsw_ObjsToInit.length; h++) { rsw_ObjsToInit[h].Init(); } for (var h = 0; h < rsw_aux_oninit_handlers.length; h++) { eval(rsw_aux_oninit_handlers[h]);
																																						 } } function rsw_spellCheckTextBox(textBox) { var found = false; if (textBox != null) { if (typeof (textBox.isStatic) == rsS50[172]) { for (var i = 0; i < rsw_scs.length;
																																						 i++) { if (rsw_scs[i].textBoxID == textBox.shadowTB.id && textBox.isDirty) { rsw_scs[i].OnSpellButtonClicked(); found = true; } else if (rsw_scs[i].textBoxID == textBox.shadowTB.id) found = true;
																																						 } } else { for (var i = 0; i < rsw_scs.length; i++) { if (rsw_scs[i].textBoxID == textBox.id) { rsw_scs[i].OnSpellButtonClicked(); found = true; } } } } if (!found && typeof(rsw_addTextBoxSpellChecker)==rsS50[88]) { rsw_addTextBoxSpellChecker(textBox, true, 0);
																																						 rsw_scs[rsw_scs.length - 1].OnSpellButtonClicked(); } } function rsw_createLink(contentWindowDoc, CssSheetURL) { var linkElement = contentWindowDoc.createElement(rsS50[173]);
																																						 linkElement.type = rsS50[174]; var url = (typeof (CssSheetURL) == rsS50[9] || CssSheetURL == rsS50[0]) ? rsw_rs_styleURL : CssSheetURL; linkElement.setAttribute(rsS50[175], url);
																																						 linkElement.setAttribute(rsS50[176], rsS50[177]); contentWindowDoc.getElementsByTagName(rsS50[178])[0].appendChild(linkElement); } function rsw_updateActiveTextbox(activeElement) { var activeID = -1;
																																						 for (var i = 0; i < rsw_tbs.length; i++) { if (activeElement == rsw_tbs[i].ifDoc || activeElement == rsw_tbs[i].iframe) { rsw_previouslyActiveTextbox = rsw_activeTextbox;
																																						 rsw_activeTextbox = rsw_tbs[i]; activeID = i; } } } function rsw_ignoreAll(error) { var errorText = error.innerHTML.replace(/<[^>]+>/g, rsS50[0]); var tError; for (var i = 0;
																																						 i<rsw_tbs.length; i++) { rsw_ignoreAllTB(errorText, rsw_tbs[i]); } } function rsw_ignoreAllTB(errorText, tb) { var errors = tb.getSpanElements(); var changeIndexes = new Array();
																																						 for (var i = 0; i < errors.length; i++) { tError = errors[i].innerHTML.replace(/<[^>]+>/g, rsS50[0]); if (errors[i].className == rsS50[179] && tError == errorText) { rsw_dehighlight(errors[i]);
																																						 rsw_addIgnoreAllWord(errorText); } } } function rsw_dehighlight(errorNode) { try { errorNode.removeNode(false); } catch (e) { errorNode.removeAttribute(rsS50[20]);
																																						 errorNode.removeAttribute(rsS50[180]); errorNode.setAttribute(rsS50[181], rsS50[0]); } } function rsw_getTargetElement(e) { var relTarg; if (!e) var e = rs_s2.event;
																																						 if (e.relatedTarget) relTarg = e.relatedTarget; else if (e.fromElement) relTarg = e.fromElement; return relTarg; } function rsw_edit(error) { rsw_activeTextbox.createEditBox(error);
																																						 rsw_activeTextbox.OnCorrection(new RSW_CorrectionEvent(rsS50[182], error.innerHTML.replace(/<[^>]+>/g, rsS50[0]), rsS50[183])); } function rsw_inlineTB_onBlur() { rsw_activeTextbox.updateShadow();
																																						 } function rsw_inlineTB_onkeypress(e) { var ev; if (typeof (e) != rsS50[9]) ev = e; else ev = event; if (ev && ev.keyCode) { if (ev.keyCode == 13) { if (ev.preventDefault) ev.preventDefault();
																																						 return false; } } return true; } function rsw_add(error) { var errorText = rsw_innerHTMLToText(error.innerHTML); rsw_ignoreAll(error); rsw_inProcessSC = rsw_activeTextbox.spellChecker;
																																						 rsw_serverAdd(errorText); } function rsw_innerHTMLToText(html) { return html.replace(/<[^>]+>/g, rsS50[0]); } function rsw_innerText(node, lastElementInCollection, lastElementInCollectionIsBR) { var t = rsS50[0];
																																						 var innerT; if (node.nodeName.toLowerCase() == rsS50[184]) t = rsS50[124]; if (node.nodeName.toLowerCase() == rsS50[185]) t = String.fromCharCode(8226); if (node.childNodes.length == 0) { if (node.nodeValue && node.nodeType == 3) { innerT = node.nodeValue;
																																						 while (rsw_newlineexp.test(innerT)) innerT = innerT.replace(rsw_newlineexp, rsS50[0]); t += innerT; } } else { for (var i = 0; i < node.childNodes.length; i++) t += rsw_innerText(node.childNodes[i]);
																																						 if (node.nodeName.toLowerCase() == rsS50[185]) t += rsS50[124]; } if(!node.scopeName || (node.scopeName==rsS50[0] || node.scopeName==rsS50[186])){ if (node.nodeName.toLowerCase() == rsS50[187]) t += node.value;
																																						 if (node.nodeName.toLowerCase() == rsS50[188] && !lastElementInCollection && (node.parentElement==null || node.parentElement.nodeName.toLowerCase()!=rsS50[26]) ) t += rsS50[124];
																																						 if (node.nodeName.toLowerCase() == rsS50[26] && !lastElementInCollection ) t += rsS50[124]; } return t; } function rsw_stringContainsWhitespaceOnly(t) { for(var i=0;
																																						 i<t.length; i++) if( !/\s/.test(t.charAt(i))) return false; return true; } var rsw_ignoreAllWords = new Array(); function rsw_addIgnoreAllWord(word) { var found = false;
																																						 for (var i = 0; i < rsw_ignoreAllWords.length; i++) if (rsw_ignoreAllWords[i] == word) found = true; if (!found) rsw_ignoreAllWords[rsw_ignoreAllWords.length] = word;
																																						 } function rsw_changeTo(error, replacement) { var orig = rsw_activeTextbox.getShadowText(); rsw_activeTextbox.changeTo(error, replacement); rsw_activeTextbox.updateShadow();
																																						 rsw_activeTextbox.OnCorrection(new RSW_CorrectionEvent(rsS50[182], error.innerHTML.replace(/<[^>]+>/g, rsS50[0]), replacement, orig)); } function rsw_changeAllTo(error, replacement) { var errorText = error.innerHTML.replace(/<[^>]+>/g, rsS50[0]);
																																						 var tError; var errors = rsw_activeTextbox.getSpanElements(); for (var i = 0; i < errors.length; i++) { tError = errors[i].innerHTML.replace(/<[^>]+>/g, rsS50[0]);
																																						 if (errors[i].className == rsS50[179] && tError == errorText) { rsw_changeTo(errors[i], replacement); i--; } } } function rsw_escapeHTML(t) { var pos = -1; while ((pos = t.indexOf(rsS50[189], pos + 1)) > -1) t = t.substring(0, pos) + rsS50[190] + t.substring(pos + 1);
																																						 var exp1 = new RegExp(rsS50[82]); while (exp1.test(t)) t = t.replace(exp1, rsS50[191]); var exp2 = new RegExp(rsS50[83]); while (exp2.test(t)) t = t.replace(exp2, rsS50[192]);
																																						 return t; } function rsw_unescapeHTML(t) { var pos = -1; while ((pos = t.indexOf(rsS50[190], pos + 1)) > -1) t = t.substring(0, pos) + rsS50[189] + t.substring(pos + 5);
																																						 var exp1 = new RegExp(rsS50[191]); while (exp1.test(t)) t = t.replace(exp1, rsS50[82]); var exp2 = new RegExp(rsS50[192]); while (exp2.test(t)) t = t.replace(exp2, rsS50[83]);
																																						 return t; } function RSWITextBox(controlClientID) { this.shadowTBID = controlClientID; this._getTBS = _getTBS; this._onKeyDown = _onKeyDown; this._onKeyUp = _onKeyUp;
																																						 this._onKeyPress = _onKeyPress; this._onCorrection = _onCorrection; this._onPaste = _onPaste; this._onContextMenu = _onContextMenu; this._onBlur = _onBlur; this._onFocus = _onFocus;
																																						 this._onMouseDown = _onMouseDown; this._onMouseUp = _onMouseUp; this.tbs = null; rsw_ObjsToInit[rsw_ObjsToInit.length] = this; this.Init = Init; function Init() { this._getTBS();
																																						 } function _getTBS() { if (this.tbs == null) { this.tbs = rsw_getTBSFromID(this.shadowTBID, false); this.tbs.repObj = this; } return this.tbs; } function _onKeyDown(e) { if (typeof (this.OnKeyDown) == rsS50[88]) this.OnKeyDown(this, e);
																																						 } function _onKeyUp(e) { if (typeof (this.OnKeyUp) == rsS50[88]) this.OnKeyUp(this, e); } function _onKeyPress(e) { if (typeof (this.OnKeyPress) == rsS50[88]) this.OnKeyPress(this, e);
																																						 } function _onCorrection(e) { if (typeof (this.OnCorrection) == rsS50[88]) this.OnCorrection(this, e); } function _onPaste(e) { if (typeof (this.OnPaste) == rsS50[88]) this.OnPaste(this, e);
																																						 } function _onContextMenu(e) { if (typeof (this.OnContextMenu) == rsS50[88]) this.OnContextMenu(this, e); } function _onBlur(e) { if (typeof (this.OnBlur) == rsS50[88]) this.OnBlur(this, e);
																																						 } function _onFocus(e) { if (typeof (this.OnFocus) == rsS50[88]) this.OnFocus(this, e); } function _onMouseDown(e) { if (typeof (this.OnMouseDown) == rsS50[88]) this.OnMouseDown(this, e);
																																						 } function _onMouseUp(e) { if (typeof (this.OnMouseUp) == rsS50[88]) this.OnMouseUp(this, e); } this.GetText = GetText; this.SetText = SetText; this.OnKeyDown; this.OnKeyUp;
																																						 this.OnKeyPress; this.OnCorrection; this.OnPaste; this.OnContextMenu; this.OnBlur; this.OnFocus; this.OnMouseDown; this.OnMouseUp; this.GetNumberOfErrors = GetNumberOfErrors;
																																						 this.Focus = Focus; this.SetDisabled = SetDisabled; this.Select = Select; function SetDisabled(disabled) { var tbs = this._getTBS(); return tbs.setDisabled(disabled);
																																						 } function Select() { var tbs = this._getTBS(); tbs.select(); } function GetText() { var tbs = this._getTBS(); return tbs.shadowTB.value; } function SetText(text) { var tbs = this._getTBS();
																																						 rsw_setShadowTB(tbs.shadowTB, text); tbs.updateIframe(); } function GetNumberOfErrors() { var tbs = this._getTBS(); return tbs.getNumberOfErrors(); } function Focus() { var tbs = this._getTBS();
																																						 return tbs.focus(); } } function RSWITextBox_DownLevel(controlClientID) { this.shadowTBID = controlClientID; this._getTBS = _getTBS; this._onKeyDown = _onKeyDown;
																																						 this._onKeyUp = _onKeyUp; this._onKeyPress = _onKeyPress; this._onCorrection = _onCorrection; this._onPaste = _onPaste; this._onContextMenu = _onContextMenu; this._onBlur = _onBlur;
																																						 this._onFocus = _onFocus; this._onMouseDown = _onMouseDown; this._onMouseUp = _onMouseUp; this.tbs = null; rsw_ObjsToInit[rsw_ObjsToInit.length] = this; RSWITextBox_DownLevels[RSWITextBox_DownLevels.length] = this;
																																						 this.Init = Init; this.shadowTB; this._getShadowTB = _getShadowTB; function Init() { this._getShadowTB().onkeydown = this._onKeyDown; this._getShadowTB().onkeyup = this._onKeyUp;
																																						 this._getShadowTB().onkeypress = this._onKeyPress; this._getShadowTB().onpaste = this._onPaste; this._getShadowTB().oncontextmenu = this._onContextMenu; this._getShadowTB().onblur = this._onBlur;
																																						 this._getShadowTB().onfocus = this._onFocus; this._getShadowTB().onmouseup = this._onMouseUp; this._getShadowTB().onmousedown = this._onMouseDown; } function _getShadowTB() { if (this.shadowTB == null) this.shadowTB = rs_s3.getElementById(this.shadowTBID);
																																						 return this.shadowTB; } function _getTBS() { if (this.tbs == null) { this.tbs = rsw_getTBSFromID(this.shadowTBID, false); this.tbs.repObj = this; } return this.tbs;
																																						 } function _tb(e) { if (e) return _findRSWITextBox_DownLevel(e.target.id); else return _findRSWITextBox_DownLevel(event.srcElement.id); } function _findRSWITextBox_DownLevel(id) { for (var i = 0;
																																						 i < RSWITextBox_DownLevels.length; i++) { if (RSWITextBox_DownLevels[i].shadowTBID == id) return RSWITextBox_DownLevels[i]; } return null; } function _onKeyDown(e) { var tb = _tb(e);
																																						 if (typeof (tb.OnKeyDown) == rsS50[88]) tb.OnKeyDown(tb, e != null ? e : event); } function _onKeyUp(e) { var tb = _tb(e); if (typeof (tb.OnKeyUp) == rsS50[88]) tb.OnKeyUp(tb, e != null ? e : event);
																																						 } function _onKeyPress(e) { var tb = _tb(e); if (typeof (tb.OnKeyPress) == rsS50[88]) tb.OnKeyPress(tb, e != null ? e : event); } function _onCorrection(e) { var tb = _tb(e);
																																						 if (typeof (tb.OnCorrection) == rsS50[88]) tb.OnCorrection(tb, e != null ? e : event); } function _onPaste(e) { var tb = _tb(e); if (typeof (tb.OnPaste) == rsS50[88]) tb.OnPaste(tb, e != null ? e : event);
																																						 } function _onContextMenu(e) { var tb = _tb(e); if (typeof (tb.OnContextMenu) == rsS50[88]) tb.OnContextMenu(tb, e != null ? e : event); } function _onBlur(e) { var tb = _tb(e);
																																						 if (typeof (tb.OnBlur) == rsS50[88]) tb.OnBlur(tb, e != null ? e : event); } function _onFocus(e) { var tb = _tb(e); if (typeof (tb.OnFocus) == rsS50[88]) tb.OnFocus(tb, e != null ? e : event);
																																						 } function _onMouseDown(e) { var tb = _tb(e); if (typeof (tb.OnMouseDown) == rsS50[88]) tb.OnMouseDown(tb, e != null ? e : event); } function _onMouseUp(e) { var tb = _tb(e);
																																						 if (typeof (tb.OnMouseUp) == rsS50[88]) tb.OnMouseUp(tb, e != null ? e : event); } this.GetText = GetText; this.SetText = SetText; this.OnKeyDown; this.OnKeyUp; this.OnKeyPress;
																																						 this.OnCorrection; this.OnPaste; this.OnContextMenu; this.OnBlur; this.OnFocus; this.OnMouseDown; this.OnMouseUp; this.GetNumberOfErrors = GetNumberOfErrors; this.Focus = Focus;
																																						 this.SetDisabled = SetDisabled; this.Select = Select; function Select() { this._getShadowTB().select(); } function SetDisabled(disabled) { this._getShadowTB().disabled = disabled;
																																						 } function GetText() { return this._getShadowTB().value; } function SetText(text) { this._getShadowTB().value = text; } function GetNumberOfErrors() { var tbs = this._getTBS();
																																						 return tbs.getNumberOfErrors(); } function Focus() { return this._getShadowTB().focus(); } } function rsw_broadcastToListeners(eventType, evt) { if (eventType == rsS50[193]) { rsw_activeTextbox.rsw_key_downed_flag = true;
																																						 rsw_activeTextbox.rsw_key_downed_within_lim = true; if (rsw_key_down_timer != null) clearTimeout(rsw_key_down_timer); rsw_key_down_timer = setTimeout(rsS50[194], rsw_key_down_timeout);
																																						 if (rsw_debug) rs_s3.getElementById(rsS50[123]).value += rsS50[124] + rsw_debug_getTime() + rsw_activeTextbox.shadowTBID+rsS50[195] + String.fromCharCode(rsw_activeTextbox.iframe.contentWindow.event.keyCode);
																																						 } if (rs_s2._INT_notifyTextBoxListeners) _INT_notifyTextBoxListeners(eventType, evt); if (rs_s2._notifyTextBoxListeners) _notifyTextBoxListeners(eventType, evt); } function RSW_IntEvent(eventType) { this.type = eventType;
																																						 } function RSW_CorrectionEvent(eventType, errorWord, replacement, oldText) { this.type = eventType; this.errorWord = errorWord, this.replacement = replacement; this.originalText = oldText;
																																						 } function IETB(iframeEl, editable) { this.iframe = iframeEl; this.editable = editable; this.ifDoc; this.initialize = initialize; this.ifDocElement; this.setContent = setContent;
																																						 this.getContent = getContent; this._onKeyPress = _onKeyPress; this._onKeyUp = _onKeyUp; this._onKeyDown = _onKeyDown; this._onPaste = _onPaste; this._onMouseDown = _onMouseDown;
																																						 this._onMouseUp = _onMouseUp; this._onContextMenu = _onContextMenu; this._onFocus = _onFocus; this._onBlur = _onBlur; this.focus = focus; this.getSpanElements = getSpanElements;
																																						 this.changeTo = changeTo; this.getAbsY = getAbsY; this.getAbsX = getAbsX; this.isStatic = false; this.getContentText = getContentText; this.selectedErrorNode = selectedErrorNode;
																																						 this.containsElement = containsElement; this.multiline = true; this.enabled = true; this.maxlength = 0; this.shadowTB; this.shadowTBID; this.updateIframe = updateIframe;
																																						 this.updateShadow = updateShadow; this.getShadowText = getShadowText; this.spellChecker; this.OnCorrection = OnCorrection; this.oldOnBlur; this.oldOnFocus; this.isDirty = false;
																																						 this.recordCaretPos = recordCaretPos; this.resetCaretPos = resetCaretPos; this.caretBL; this.caretBT; this.selectedText; this.CssSheetURL; this.getNumberOfErrors = getNumberOfErrors;
																																						 this.textIsXHTML; this.unhook = unhook; this.repObj = null; this.setDisabled = setDisabled; this.select = select; this.isFocused = false; this.insertErrorHighlights = insertErrorHighlights;
																																						 this.attachEvents = attachEvents; this.isVisible = isVisible; function isVisible() { var rect = this.iframe.getBoundingClientRect(); return rect.left != 0 || rect.top != 0 || rect.bottom != 0 || rect.right != 0;
																																						 } function select() { this.focus(); var r = this.ifDoc.selection.createRange(); r.expand(rsS50[196]); r.select(); } function getNumberOfErrors() { var errors = this.getSpanElements();
																																						 var numErrors = 0; for (var i = 0; i < errors.length; i++) { if (errors[i].className == rsS50[179]) { numErrors++; } } return numErrors; } function insertErrorHighlights(result, client) { try { var selection = this.ifDoc.selection;
																																						 var selRange = selection.createRange().duplicate(); var bookmark = selRange.getBookmark(); var range; var numRs; var content = this.getContentText(); var calibration = -1;
																																						 range = this.ifDoc.body.createTextRange().duplicate(); range.collapse(true); var contentChar; var rangeCharCode; var contentCharCode; var lookingForLeadingSpace = false;
																																						 var start = 0; var k = 0; var numberOfChars = 0; for (var i = 0; i < result.errorPositionArray.length; i++) { if (i > 0) start = result.errorPositionArray[i - 1].start;
																																						 lookingForLeadingSpace = result.errorPositionArray[i].word.charAt(0) == rsS50[15]; if (lookingForLeadingSpace) result.errorPositionArray[i].start++; for (var j = start;
																																						 j <= result.errorPositionArray[i].start; j++) { contentCharCode = content.charCodeAt(j); if ( (contentCharCode > 0x20 && contentCharCode < 0x7f) || contentCharCode > 0xA1 ) numberOfChars++;
																																						 } do { range.moveEnd(rsS50[197], 1); rangeCharCode = range.text.charCodeAt(0); if ((rangeCharCode > 0x20 && rangeCharCode < 0x7f) || rangeCharCode > 0xA1) k++; range.move(rsS50[197], 1);
																																						 } while (k < numberOfChars); if (lookingForLeadingSpace) range.move(rsS50[197], -2); else range.move(rsS50[197], -1); var startRangeParent = range.parentElement();
																																						 if (lookingForLeadingSpace) delta = -1; else delta = 0; range.moveEnd(rsS50[197], (result.errorPositionArray[i].end - result.errorPositionArray[i].start) - delta);
																																						 var rangeParent = range.parentElement(); if (rangeParent.nodeName == rsS50[198]) { rangeParent.removeNode(false); rangeParent = range.parentElement(); } if (rangeParent != null && (rangeParent.getAttribute(rsS50[20]) == null || rangeParent.getAttribute(rsS50[20]) != rsS50[179]) && range.text == result.errorPositionArray[i].word) { if (startRangeParent.getAttribute(rsS50[20]) == rsS50[179]) startRangeParent.removeNode(false);
																																						 range.execCommand(rsS50[199], false); var span = this.ifDoc.createElement(rsS50[200]); span.setAttribute(rsS50[180], rsS50[179]); span.setAttribute(rsS50[20], rsS50[179]);
																																						 var mouseup = client.createErrorMouseUp(result.errorPositionArray[i].suggestions); span.setAttribute(rsS50[201], mouseup); span.onmouseup = function () { rsw_clickedSpan = this;
																																						 }; span.attachEvent(rsS50[181], function () { if (rsw_clickedSpan != null) { rsw_showMenu(eval(rsS50[202] + rsw_clickedSpan.getAttribute(rsS50[201]) + rsS50[203]), rsw_clickedSpan, arguments[0]);
																																						 } rsw_clickedSpan = null; }); span.oncontextmenu = function () { try { event.cancelBubble = true; event.preventDefault(); } catch (e) { } return false; }; var italic = range.parentElement();
																																						 italic.applyElement(span, rsS50[204]); italic.removeNode(false); } } } catch (e) { } } function recordCaretPos() { try { var selection = this.ifDoc.selection; var range = selection.createRange().duplicate();
																																						 if (rsw_ie9) { var start = 0, end = 0, normalizedValue, textInputRange, len, endRange; el = this.ifDoc; this.origTextInRange = this.getContentText(); len = this.origTextInRange.length;
																																						 normalizedValue = this.origTextInRange.replace(/\r\n/g, rsS50[11]); textInputRange = this.ifDoc.body.createTextRange(); textInputRange.moveToBookmark(range.getBookmark());
																																						 endRange = this.ifDoc.body.createTextRange(); endRange.collapse(false); if (rsw_debug) rs_s3.getElementById(rsS50[123]).value += rsS50[205] + textInputRange.text + rsS50[15] + textInputRange.compareEndPoints(rsS50[206], endRange);
																																						 if (textInputRange.compareEndPoints(rsS50[206], endRange) > -1) { start = end = len; } else { start = -textInputRange.moveStart(rsS50[197], -len); if (rsw_debug) rs_s3.getElementById(rsS50[123]).value += rsS50[207] + textInputRange.compareEndPoints(rsS50[208], endRange);
																																						 if (textInputRange.compareEndPoints(rsS50[208], endRange) > -1) { end = len; } else { end = -textInputRange.moveEnd(rsS50[197], -len); end += normalizedValue.slice(0, end).split(rsS50[11]).length - 1;
																																						 } } this.cursorPosition = start; } else { range.moveStart(rsS50[209], -9000000); this.origTextInRange = range.text.replace(/\n/g, rsS50[0]); this.cursorPosition = this.origTextInRange.length;
																																						 } if (rsw_debug) rs_s3.getElementById(rsS50[123]).value += rsS50[210] + this.cursorPosition; } catch (e) { } } function resetCaretPos() { try { var selection = this.ifDoc.selection;
																																						 var newRange = selection.createRange(); newRange.move(rsS50[209], -9000000); var o = newRange.moveEnd(rsS50[197], this.cursorPosition); var ignNewL = this.origTextInRange.replace(/\r/g, rsS50[0]);
																																						 if (rsw_debug) rs_s3.getElementById(rsS50[123]).value += rsS50[211] + o + rsS50[212] + newRange.text.indexOf(rsS50[100]) + rsS50[213] + newRange.text.replace(/\r\n/g, rsS50[11]) + rsS50[214] + ignNewL + rsS50[215];
																																						 ; var moveAmount = 1; if (navigator.userAgent.indexOf(rsS50[216]) > -1) newRange.moveStart(rsS50[197], this.cursorPosition); else newRange.collapse(false); newRange.select();
																																						 } catch (e) { } } function OnCorrection(e) { if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onCorrection(e); rsw_broadcastToListeners(rsS50[182]);
																																						 } function focus() { this.iframe.contentWindow.focus(); try { this.iframe.focus(); } catch (e) { } this.iframe.contentWindow.focus(); try { var caret = this.ifDoc.selection.createRange();
																																						 correctCaret(caret); } catch (e) { } } function containsElement(element) { return element.ownerDocument == this.ifDoc; } function selectedErrorNode() { try { var selection = rsw_activeTextbox.ifDoc.selection;
																																						 var parentEl = selection.createRange().parentElement(); if (parentEl.className == rsS50[179]) return parentEl; else { if (parentEl.children.length > 0 && parentEl.children[parentEl.children.length - 1].className==rsS50[179]) { var r = this.ifDoc.body.createTextRange();
																																						 r.moveToElementText(parentEl.children[parentEl.children.length - 1]); if (r.compareEndPoints(rsS50[208], selection.createRange()) == 0) { return parentEl.children[parentEl.children.length - 1];
																																						 } } return null; } } catch (e) { return null; } } function getAbsX(element, event) { var obj = this.iframe; var curLeft = 0; var index = 0; if (obj.offsetParent) { while (obj.offsetParent) { index++;
																																						 var delta = 0; if (!window.opera && index > 1) delta = obj.scrollLeft; curLeft += obj.offsetLeft - delta; obj = obj.offsetParent; } } else if (obj.clientY) curLeft += obj.clientY;
																																						 return curLeft + element.offsetLeft - this.ifDoc.body.scrollLeft; } function getAbsY(element, event) { var obj = this.iframe; var curtop = 0; var index = 0; if (obj.offsetParent) { while (obj.offsetParent) { index++;
																																						 var delta = 0; if (!window.opera && index > 1) delta = obj.scrollTop; curtop += obj.offsetTop - delta; obj = obj.offsetParent; } } else if (obj.clientY) curtop += obj.clientY;
																																						 return curtop + element.offsetTop - this.ifDoc.body.scrollTop; } function changeTo(error, replacement) { try { var repl = this.ifDoc.createTextNode(replacement); error.parentNode.replaceChild(repl, error);
																																						 } catch (e) { return null; } } function getSpanElements() { return this.ifDoc.getElementsByTagName(rsS50[200]); } function _onKeyPress() { rsw_hideCM(); var evt = rsw_activeTextbox.iframe.contentWindow.event;
																																						 var errorNode = rsw_activeTextbox.selectedErrorNode(); if (errorNode) rsw_dehighlight(errorNode); if (evt != null && evt.keyCode == 13 && !rsw_activeTextbox.multiline) { evt.returnValue = false;
																																						 } else if (evt != null && evt.keyCode == 13) { } rsw_activeTextbox.isDirty = true; if (rsw_activeTextbox.maxlength > 0) { if (rsw_activeTextbox.getContentText().replace(/\r/g, rsS50[0]).replace(/\n/g, rsS50[0]).length >= rsw_activeTextbox.maxlength) evt.returnValue = false;
																																						 } if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyPress(rsw_activeTextbox.iframe.contentWindow.event); rsw_broadcastToListeners(rsS50[217]); } function _onKeyDown() { if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyDown(rsw_activeTextbox.iframe.contentWindow.event);
																																						 rsw_broadcastToListeners(rsS50[193]); } function _onKeyUp() { rsw_hideCM(); if (!rsw_ie9) rsw_activeTextbox.ifDoc.body.createTextRange().execCommand(rsS50[218]); var evt = rsw_activeTextbox.iframe.contentWindow.event;
																																						 if (evt == null || !(evt.keyCode >= 33 && evt.keyCode <= 40)) { var errorNode = rsw_activeTextbox.selectedErrorNode(); if (errorNode) rsw_dehighlight(errorNode); } rsw_activeTextbox.updateShadow();
																																						 if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyUp(evt); rsw_broadcastToListeners(rsS50[219], evt); } function _onMouseDown() { if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseDown(rsw_activeTextbox.iframe.contentWindow.event);
																																						 rsw_hideCM(); rsw_broadcastToListeners(rsS50[220]); rsw_activeTextbox.updateShadow(); } function _onMouseUp() { if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseUp(rsw_activeTextbox.iframe.contentWindow.event);
																																						 rsw_broadcastToListeners(rsS50[221]); } function _onFocus(event, circle) { if (typeof (rsw_activeTextbox.iframe.contentWindow) != rsS50[9]) rsw_yScroll = rsw_getScrollY(rsw_activeTextbox.iframe.contentWindow);
																																						 rsw_activeTextbox.isFocused = true; if (typeof (rsw_useIFrameMenuBacker) == rsS50[9] || rsw_useIFrameMenuBacker) rsw_hideCM(); rsw_activeTextbox.updateShadow(); rsw_updateActiveTextbox(this);
																																						 if (rsw_correctCaret) { var caret = rsw_activeTextbox.ifDoc.selection.createRange(); correctCaret(caret); } rsw_broadcastToListeners(rsS50[222]); if (navigator.userAgent.indexOf(rsS50[216]) > -1 || navigator.userAgent.indexOf(rsS50[223]) > -1) { rsw_activeTextbox.ifDoc.body.setAttribute(rsS50[224], rsS50[119]);
																																						 if (rsw_yScroll != null) rsw_setScrollY(rsw_activeTextbox.iframe.contentWindow, rsw_yScroll ); } if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onFocus(new RSW_IntEvent(rsS50[222]));
																																						 if (rsw_activeTextbox.oldOnFocus && rsw_activeTextbox.oldOnFocus != rsw_activeTextbox._onFocus && !circle) rsw_activeTextbox.oldOnFocus(event, true); } function _onBlur(event, circle) { rsw_activeTextbox.isFocused = false;
																																						 rsw_activeTextbox.rsw_key_downed_within_lim = false; rsw_activeTextbox.updateShadow(); function callOnchange(event, textbox) { return function () { try { if (typeof (rsw_fireEventInShadow) == rsS50[88]) rsw_fireEventInShadow(rsS50[225], textbox);
																																						 else if (typeof (textbox.shadowTB.onchange) == rsS50[88]) textbox.shadowTB.onchange(event); } catch (x) { } } } if (rsw_activeTextbox.shadowTB.defaultValue != rsw_activeTextbox.shadowTB.value) setTimeout(callOnchange(event, rsw_activeTextbox), 100);
																																						 if (navigator.userAgent.indexOf(rsS50[216]) > -1 || navigator.userAgent.indexOf(rsS50[223]) > -1) rsw_activeTextbox.ifDoc.body.setAttribute(rsS50[224], rsS50[226]);
																																						 if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onBlur(new RSW_IntEvent(rsS50[227])); if (rsw_debug) rs_s3.getElementById(rsS50[123]).value += rsS50[228];
																																						 if (rsw_activeTextbox.isAYT) rsw_spellCheckTextBox(rsw_activeTextbox); rsw_broadcastToListeners(rsS50[227]); if (rsw_activeTextbox.oldOnBlur && rsw_activeTextbox.oldOnBlur != rsw_activeTextbox._onBlur && !circle) rsw_activeTextbox.oldOnBlur(event, true);
																																						 } function setContent(content, contentIsFromShadow) { if (rsw_debug) rs_s3.getElementById(rsS50[123]).value += rsS50[229] + content + rsS50[230] + contentIsFromShadow;
																																						 var pos = -1; var ppos = 0; var t = rsS50[0]; while ((pos = content.indexOf(rsS50[11], pos + 1)) > -1) { if (pos > ppos + 2) { if (content.substring(pos - 1, pos) == rsS50[100]) t += content.substring(ppos, pos - 1) + rsS50[231];
																																						 else t += content.substring(ppos, pos) + rsS50[231]; } else { if (content.charAt(ppos) != rsS50[100]) t += content.substring(ppos, pos) + rsS50[231]; else t += rsS50[231];
																																						 } ppos = pos + 1; } if ((ppos < content.length || ppos == 0) && !rsw_ie9Standards) { } else if (ppos == content.length) { } else { } t += content.substring(ppos, content.length);
																																						 if (!this.multiline) { var pos = -1; var ppos = 0; var opener = -1; var closer = -1; while ((pos = t.indexOf(rsS50[15], pos + 1)) > -1) { opener = t.lastIndexOf(rsS50[82], pos);
																																						 closer = t.lastIndexOf(rsS50[83], pos); if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) t = t.substring(0, pos) + String.fromCharCode(160) + t.substring(pos + 1);
																																						 ppos = pos; } t = rsS50[232] + t + rsS50[233]; } else { var pos = -1; var ppos = 0; var opener = -1; var closer = -1; var flag = true; while ((pos = t.indexOf(rsS50[15], pos + 1)) > -1) { if (pos + 1 < t.length && (t.charAt(pos + 1) == rsS50[15] || (pos > 4 && t.charAt(pos - 1) == rsS50[83] && t.substring(pos - 5, pos - 1) != rsS50[200]))) { opener = t.lastIndexOf(rsS50[82], pos);
																																						 closer = t.lastIndexOf(rsS50[83], pos); if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) { t = t.substring(0, pos) + String.fromCharCode(160) + t.substring(pos + 1);
																																						 } ppos = pos; } } } if(this.ifDoc.body!=null) this.ifDoc.body.innerHTML = t; if (!contentIsFromShadow) this.updateShadow(); } function correctCaret(caret) { if (caret.text.length == 0 && caret.moveStart(rsS50[197], -1) < 0) { caret.select();
																																						 caret.moveStart(rsS50[197], 1); caret.select(); caret.collapse(true); } caret.select(); } function getContent() { return this.ifDoc.body.innerHTML; } function getContentText() { if (this.ifDocElement == null) return rsS50[0];
																																						 var contentElements = this.ifDocElement.childNodes[1].childNodes; var contents = rsS50[0]; for (var i = 0; i < contentElements.length; i++) { if (contentElements[i].nodeValue) contents += contentElements[i].nodeValue;
																																						 else if (contentElements[i].nodeName.toLowerCase() == rsS50[184] && i < contentElements.length - 1) contents += rsS50[124]; else if (contentElements[i].nodeName.toLowerCase() == rsS50[187]) contents += contentElements[i].value;
																																						 else contents += rsw_innerText(contentElements[i], i == contentElements.length - 1, contentElements[contentElements.length - 1].nodeName.toLowerCase() == rsS50[184]);
																																						 } return contents; } function _onContextMenu() { if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onContextMenu(rsw_activeTextbox.iframe.contentWindow.event);
																																						 rsw_broadcastToListeners(rsS50[234]); } function _onPaste() { if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onPaste(rsw_activeTextbox.iframe.contentWindow.event);
																																						 var errorNode = rsw_activeTextbox.selectedErrorNode(); if (errorNode) rsw_dehighlight(errorNode); setTimeout(rsS50[235]+ rsS50[236], 300); rsw_broadcastToListeners(rsS50[237]);
																																						 } function initialize(attempts) { var ifID; if (!this.iframe) ifID = this.tbConfig.values[0]; else ifID = this.iframe.id; this.shadowTBID = ifID.substring(0, ifID.length - 3);
																																						 this.shadowTB = rs_s3.getElementById(this.shadowTBID); if (rsw_id_waitingToInitialize == null) rsw_id_waitingToInitialize = ifID; if (!attempts) attempts = 0; if ((!this.iframe.contentWindow.loaded && attempts < 100) || attempts == 0 || rsw_id_waitingToInitialize != ifID) { var time = 50 + Math.floor(Math.random() * 50);
																																						 attempts++; eval(rsS50[238] + this.shadowTBID + rsS50[239] + attempts + rsS50[240] + time + rsS50[241]); return; } rsw_id_waitingToInitialize = null; this.ifDoc = this.iframe.contentWindow.document;
																																						 this.ifDocElement = this.iframe.contentWindow.document.documentElement; rsw_createLink(this.ifDoc, this.CssSheetURL); this.ifDoc.styleSheets[0].addRule(rsS50[242], rsS50[243]);
																																						 if (this.enabled) { if (this.editable) { this.ifDoc.body.setAttribute(rsS50[224], rsS50[119]); } this.attachEvents(); } rsw_setSettings(this); } function attachEvents() { if (this.ifDocElement.onmousedown != this._onMouseDown) { this.ifDocElement.onmousedown = this._onMouseDown;
																																						 this.ifDocElement.onmouseup = this._onMouseUp; this.ifDocElement.onkeypress = this._onKeyPress; this.ifDocElement.onkeydown = this._onKeyDown; this.ifDocElement.onkeyup = this._onKeyUp;
																																						 this.ifDocElement.onpaste = this._onPaste; } if (this._onFocus != this.iframe.onfocus) { this.oldOnFocus = this.iframe.onfocus; this.iframe.onfocus = this._onFocus;
																																						 this.oldOnBlur = this.iframe.onblur; this.iframe.onblur = this._onBlur; this.ifDoc.oncontextmenu = this._onContextMenu; } try { rs_s3.execCommand(rsS50[244], false, false);
																																						 } catch (exc) { } } function setDisabled(disabled) { this.ifDoc.body.setAttribute(rsS50[224], !disabled); this.enabled = !disabled; if (this.enabled) this.attachEvents();
																																						 if (typeof (rsw_ignoreDisabledBoxes) != rsS50[9] && rsw_ignoreDisabledBoxes && disabled) this.updateIframe(); if (this.enabled) this.attachEvents(); if (this.multiline) { if (disabled) this.ifDoc.body.className = rsS50[245];
																																						 else this.ifDoc.body.className = rsS50[246]; } else { if (disabled) this.ifDoc.body.className = rsS50[247]; else this.ifDoc.body.className = rsS50[248]; } } function unhook() { this.ifDoc.body.setAttribute(rsS50[224], rsS50[226]);
																																						 this.ifDocElement.onmousedown = null; this.ifDocElement.onmouseup = null; this.ifDocElement.onkeypress = null; this.ifDocElement.onkeydown = null; this.ifDocElement.onkeyup = null;
																																						 this.ifDocElement.onpaste = null; this.oldOnFocus = null; this.iframe.onfocus = null; this.oldOnBlur = null; this.iframe.onblur = null; this.ifDoc.oncontextmenu = null;
																																						 } function updateIframe() { if (this.textIsXHTML) this.setContent((this.shadowTB.value), true); else this.setContent(rsw_escapeHTML(this.shadowTB.value), true); } function updateShadow() { var reg = new RegExp(String.fromCharCode(160), rsS50[249]);
																																						 rsw_setShadowTB(this.shadowTB, this.getContentText().replace(reg, rsS50[15])); } function getShadowText() { return this.shadowTB.value; } } function MozlyTB(iframeEl, editable) { this.iframe = iframeEl;
																																						 this.editable = editable; this.ifDoc; this.designMode; this.initialize = initialize; this.ifDocElement; this.setContent = setContent; this.getContent = getContent;
																																						 this._onKeyPress = _onKeyPress; this._onKeyUp = _onKeyUp; this._onKeyDown = _onKeyDown; this._onMouseDown = _onMouseDown; this._onMouseUp = _onMouseUp; this._onFocus = _onFocus;
																																						 this.isFocused = false; this._onBlur = _onBlur; this._onClick = _onClick; this._onContextMenu = _onContextMenu; this.getSpanElements = getSpanElements; this.changeTo = changeTo;
																																						 this.getAbsY = getAbsY; this.getAbsX = getAbsX; this.isStatic = false; this.getContentText = getContentText; this.selectedErrorNode = selectedErrorNode; this.containsElement = containsElement;
																																						 this.focus = focus; this.multiline = false; this.enabled = true; this.maxlength = 0; this.shadowTB; this.updateIframe = updateIframe; this.updateShadow = updateShadow;
																																						 this.getShadowText = getShadowText; this.spellChecker; this.OnCorrection = OnCorrection; this.isWrappedInNOBR = false; this.oldOnBlur; this.oldOnFocus; this.isDirty = false;
																																						 this.recordCaretPos = recordCaretPos; this.resetCaretPos = resetCaretPos; this.selOffset; this.selOffsetEnd; this.CssSheetURL; this.getNumberOfErrors = getNumberOfErrors;
																																						 this.textIsXHTML; this.unhook = unhook; this.repObj = null; this.setDisabled = setDisabled; this.select = select; this.attachEvents = attachEvents; this.isVisible = isVisible;
																																						 function isVisible() { var rect = this.iframe.getBoundingClientRect(); return rect.left != 0 || rect.top != 0 || rect.width != 0 || rect.height != 0; } function select() { this.focus();
																																						 if (this.getContentText().length > 0) { var sel = this.iframe.contentWindow.getSelection(); var range = sel.getRangeAt(0); var contentElements = this.ifDoc.body.childNodes;
																																						 range.setStartBefore(contentElements[0]); range.setEndAfter(contentElements[contentElements.length - 1]); } } function getNumberOfErrors() { var errors = this.getSpanElements();
																																						 var numErrors = 0; for (var i = 0; i < errors.length; i++) { if (errors[i].className == rsS50[179]) { numErrors++; } } return numErrors; } function recordCaretPos() { try { var sel = this.iframe.contentWindow.getSelection();
																																						 var range = sel.getRangeAt(0); var len = 0; var contentElements = this.ifDoc.body.childNodes; this.selOffset = rsw_getAbsSel(range, len, contentElements)[0]; this.selOffsetEnd = rsw_getAbsSel(range, len, contentElements, true)[0];
																																						 } catch (e) { } } function resetCaretPos() { try { var sel = this.iframe.contentWindow.getSelection(); var range = sel.getRangeAt(0); var contentElements = this.ifDoc.body.childNodes;
																																						 var absRange = rsw_getAbsRance(0, this.selOffset, contentElements); var absRangeEnd = rsw_getAbsRance(0, this.selOffsetEnd, contentElements); if (absRangeEnd[4]) range.setEndAfter(absRangeEnd[2]);
																																						 else range.setEnd(absRangeEnd[2], absRangeEnd[3]); if (absRange[4]) range.setStartAfter(absRange[2]); else range.setStart(absRange[2], absRange[3]); } catch (e) { try { var range = sel.getRangeAt(0);
																																						 var contentElements = this.ifDoc.body.childNodes; var lastElPtr = contentElements.length - 1; while (!contentElements[lastElPtr].nodeValue && lastElPtr > 0) { lastElPtr--;
																																						 } range.setEnd(contentElements[lastElPtr], contentElements[lastElPtr].nodeValue.length); range.setStart(contentElements[lastElPtr], contentElements[lastElPtr].nodeValue.length);
																																						 } catch (ex) { } } } function OnCorrection(e) { if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onCorrection(e); rsw_broadcastToListeners(rsS50[182]);
																																						 } function focus() { this.iframe.contentWindow.focus(); } function containsElement(element) { return element.ownerDocument == this.ifDoc; } function selectedErrorNode() { try { var selection = rsw_activeTextbox.iframe.contentWindow.getSelection();
																																						 if (selection.anchorNode.parentNode.className == rsS50[179]) return selection.anchorNode.parentNode; else return null; } catch (e) { return null; } } function getAbsX(element, event) { var obj = this.iframe;
																																						 var curLeft = 0; var index = 0; if (obj.offsetParent) { while (obj.offsetParent) { index++; var delta = 0; if (!window.opera && index > 1) delta = obj.scrollLeft;
																																						 curLeft += obj.offsetLeft - delta; obj = obj.offsetParent; } } else if (obj.clientY) curLeft += obj.clientY; return curLeft + element.offsetLeft - this.iframe.scrollTop - this.ifDoc.body.scrollLeft;
																																						 } function getAbsY(element, event) { var obj = this.iframe; var curtop = 0; var index = 0; if (obj.offsetParent) { while (obj.offsetParent) { index++; var delta = 0;
																																						 if (!window.opera && index > 1) delta = obj.scrollTop; curtop += obj.offsetTop - delta; obj = obj.offsetParent; } } else if (obj.clientY) curtop += obj.clientY; return curtop + element.offsetTop - this.iframe.scrollTop - this.ifDoc.body.scrollTop;
																																						 } function changeTo(error, replacement) { var repl = this.ifDoc.createTextNode(replacement); error.parentNode.replaceChild(repl, error); } function getSpanElements() { return this.ifDoc.getElementsByTagName(rsS50[200]);
																																						 } function getContentText() { var contentElements = this.ifDoc.body.childNodes; var contents = rsS50[0]; var innerT = rsS50[0]; for (var i = 0; i < contentElements.length;
																																						 i++) { if (contentElements[i].nodeName.toLowerCase() == rsS50[187]) contents += contentElements[i].value; else if (contentElements[i].nodeName.toLowerCase() != rsS50[184] || i < contentElements.length - 1) { innerT = rsw_innerText(contentElements[i]);
																																						 contents += innerT; } } return contents; } function _onClick(event) { if (navigator.userAgent.toLowerCase().indexOf(rsS50[250]) == -1 && navigator.userAgent.toLowerCase().indexOf(rsS50[251]) > -1) { if (typeof event != rsS50[9]) { try { var embedhandler = event.target.attributes[rsS50[181]].nodeValue;
																																						 var suggestionsString = rsS50[202] + embedhandler.substring(embedhandler.indexOf(rsS50[202]) + 1, embedhandler.indexOf(rsS50[203]) + 1); var suggestions = eval(suggestionsString);
																																						 rsw_showMenu(suggestions, event.target, event); } catch (ex) { } } } } function _onKeyPress(event) { rsw_hideCM(); var evt = event; if (evt != null && evt.keyCode == 13 && !rsw_activeTextbox.multiline) { event.preventDefault();
																																						 event.cancelBubble = true; } if (evt != null && evt.keyCode == 9) { } rsw_activeTextbox.isDirty = true; if (rsw_activeTextbox.maxlength > 0) { if ( evt.keyCode != 8 && evt.keyCode != 46 && (evt.keyCode < 33 || evt.keyCode > 40) && rsw_activeTextbox.getContentText().replace(/\r/g, rsS50[0]).replace(/\n/g, rsS50[0]).length >= rsw_activeTextbox.maxlength) { event.preventDefault();
																																						 event.cancelBubble = true; } } if (!rsw_activeTextbox.multiline && rsw_activeTextbox.getContentText() == rsS50[124]) { var els = rsw_activeTextbox.ifDoc.getElementsByTagName(rsS50[252]);
																																						 for (var xi = 0; xi < els.length; xi++) { els[xi].parentNode.removeChild(els[xi]); } } if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyPress(event);
																																						 rsw_broadcastToListeners(rsS50[217]); } function _onKeyDown(event) { if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyDown(event); rsw_broadcastToListeners(rsS50[193]);
																																						 } function _onFocus(event) { rsw_activeTextbox.isFocused = true; rsw_hideCM(); rsw_activeTextbox.updateShadow(); rsw_updateActiveTextbox(this); if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onFocus(event);
																																						 rsw_broadcastToListeners(rsS50[222]); } function _onBlur(event) { rsw_activeTextbox.isFocused = false; rsw_activeTextbox.rsw_key_downed_within_lim = false; rsw_activeTextbox.updateShadow();
																																						 if (rsw_activeTextbox.shadowTB.onchange) { if (rsw_activeTextbox.shadowTB.defaultValue != rsw_activeTextbox.shadowTB.value) { var evt = rs_s3.createEvent(rsS50[253]);
																																						 evt.initUIEvent(rsS50[225], event.canBubble, event.cancelable, event.view, event.detail); rsw_activeTextbox.shadowTB.dispatchEvent(evt); } } if(rsw_activeTextbox.isAYT) rsw_spellCheckTextBox(rsw_activeTextbox);
																																						 if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onBlur(event); rsw_broadcastToListeners(rsS50[227]); } function _onKeyUp(event) { if (event == null || !(event.keyCode >= 33 && event.keyCode <= 40)) { var errorNode = rsw_activeTextbox.selectedErrorNode();
																																						 if (errorNode) rsw_dehighlight(errorNode); } rsw_activeTextbox.updateShadow(); if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyUp(event); rsw_broadcastToListeners(rsS50[219]);
																																						 } function _onMouseDown(event) { rsw_hideCM(); if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseDown(event); rsw_broadcastToListeners(rsS50[220]);
																																						 rsw_activeTextbox.updateShadow(); } function _onMouseUp(event) { if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseUp(event); rsw_broadcastToListeners(rsS50[221]);
																																						 } function setContent(content) { var t = content; if (this.multiline) { while (rsw_newlineexp.test(t)) t = t.replace(rsw_newlineexp, rsS50[254]); } var newlineexp = new RegExp(rsS50[100]);
																																						 while (newlineexp.test(t)) t = t.replace(newlineexp, rsS50[0]); if (!this.multiline) { var pos = -1; var ppos = 0; var opener = -1; var closer = -1; while ((pos = t.indexOf(rsS50[15], pos + 1)) > -1) { opener = t.lastIndexOf(rsS50[82], pos);
																																						 closer = t.lastIndexOf(rsS50[83], pos); if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) t = t.substring(0, pos) + rsS50[255] + t.substring(pos + 1);
																																						 ppos = pos; } if (t.length == 0) t = rsS50[0]; else { t = rsS50[232] + t + rsS50[233]; this.isWrappedInNOBR = true; } } else { var pos = -1; var ppos = 0; var opener = -1;
																																						 var closer = -1; var flag = true; while ((pos = t.indexOf(rsS50[15], pos + 1)) > -1) { if (pos + 1 < t.length && (t.charAt(pos + 1) == rsS50[15] || (pos > 4 && t.charAt(pos - 1) == rsS50[83] && t.substring(pos - 5, pos - 1) != rsS50[200]))) { opener = t.lastIndexOf(rsS50[82], pos);
																																						 closer = t.lastIndexOf(rsS50[83], pos); if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) { t = t.substring(0, pos) + String.fromCharCode(160) + t.substring(pos + 1);
																																						 } ppos = pos; } } t += rsS50[256]; } this.ifDoc.body.innerHTML = t; this.updateShadow(); } function getContent() { return this.ifDoc.body.innerHTML; } function setDisabled(disabled) { if (disabled) this.iframe.contentDocument.designMode = rsS50[257];
																																						 else this.iframe.contentDocument.designMode = rsS50[258]; this.enabled = !disabled; if (typeof (rsw_ignoreDisabledBoxes) != rsS50[9] && rsw_ignoreDisabledBoxes && disabled) this.updateIframe();
																																						 if (this.multiline) { if (disabled) this.ifDoc.body.className = rsS50[245]; else this.ifDoc.body.className = rsS50[246]; } else { if (disabled) this.ifDoc.body.className = rsS50[247];
																																						 else this.ifDoc.body.className = rsS50[248]; } } function _onContextMenu(e) { if (rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onContextMenu(e); if (rsw_MenuOnRightClick) { e.cancelBubble = true;
																																						 e.preventDefault(); } rsw_broadcastToListeners(rsS50[234]); } function initialize(attempts) { var ifID = this.iframe.id; this.shadowTBID = ifID.substring(0, ifID.length - 3);
																																						 this.shadowTB = rs_s3.getElementById(this.shadowTBID); if (!attempts) attempts = 0; if (!this.iframe.contentWindow.loaded && attempts < 100) { eval(rsS50[259] + this.shadowTBID + rsS50[239] + attempts + rsS50[260]);
																																						 return; } this.ifDoc = this.iframe.contentWindow.document; this.iframe.contentWindow.document.documentElement.setAttribute(rsS50[261], false); this.ifDocElement = this.iframe.contentWindow.document.documentElement;
																																						 rsw_createLink(this.ifDoc, this.CssSheetURL); if (this.enabled) { if (this.editable) { eval(rsS50[262] + this.iframe.id + rsS50[263]); this.attachEvents(); } } rsw_setSettings(this);
																																						 if (rsw_ffMaxLengthChecker == null && this.maxlength > 0) rsw_ffMaxLengthChecker = setInterval(rsS50[264], 300); } function attachEvents() { this.ifDoc.addEventListener(rsS50[220], this._onMouseDown, false);
																																						 this.ifDoc.addEventListener(rsS50[221], this._onMouseUp, false); this.ifDoc.addEventListener(rsS50[217], this._onKeyPress, false); this.ifDoc.addEventListener(rsS50[193], this._onKeyDown, false);
																																						 this.ifDoc.addEventListener(rsS50[219], this._onKeyUp, false); this.ifDoc.addEventListener(rsS50[234], this._onContextMenu, false); this.ifDoc.addEventListener(rsS50[222], this._onFocus, false);
																																						 this.ifDoc.addEventListener(rsS50[227], this._onBlur, false); this.ifDoc.addEventListener(rsS50[265], this._onClick, false); if (typeof (this.tbConfig) != rsS50[9] && this.tbConfig != null && this.tbConfig.keys != null) { for (var v = 0;
																																						 v < this.tbConfig.keys.length; v++) if (this.tbConfig.keys[v] == rsS50[266]) this.multiline = this.tbConfig.values[v]; if (!this.multiline && rsw_showHorizScrollBarsInFF) { this.iframe.scrolling = rsS50[267];
																																						 for (var v = 0; v < this.tbConfig.keys.length; v++) { if (this.tbConfig.keys[v] == rsS50[268]) { var hstr = parseInt(this.tbConfig.values[v].substring(1, this.tbConfig.values[v].length - 3), 10) + 22;
																																						 if (hstr < 50) this.tbConfig.values[v] = rsS50[89] + hstr + rsS50[269]; } } } } } function unhook() { this.ifDoc.removeEventListener(rsS50[220], this._onMouseDown, false);
																																						 this.ifDoc.removeEventListener(rsS50[221], this._onMouseUp, false); this.ifDoc.removeEventListener(rsS50[217], this._onKeyPress, false); this.ifDoc.removeEventListener(rsS50[193], this._onKeyDown, false);
																																						 this.ifDoc.removeEventListener(rsS50[219], this._onKeyUp, false); this.ifDoc.removeEventListener(rsS50[234], this._onContextMenu, false); this.ifDoc.removeEventListener(rsS50[222], this._onFocus, false);
																																						 this.ifDoc.removeEventListener(rsS50[227], this._onBlur, false); this.ifDoc.removeEventListener(rsS50[265], this._onClick, false); } function updateIframe() { if (this.textIsXHTML) this.setContent((this.shadowTB.value), true);
																																						 else this.setContent(rsw_escapeHTML(this.shadowTB.value), true); } function updateShadow() { var reg = new RegExp(String.fromCharCode(160), rsS50[249]); rsw_setShadowTB(this.shadowTB, this.getContentText().replace(reg, rsS50[15]));
																																						 } function getShadowText() { return this.shadowTB.value; } } function OldIETB(iframe) { this.iframe = iframe; this.ifDoc; this.initialize = initialize; this.ifDocElement;
																																						 this.setContent = setContent; this.getContent = getContent; this._onKeyPress = _onKeyPress; this._onPaste = _onPaste; this._onMouseDown = _onMouseDown; this._onContextMenu = _onContextMenu;
																																						 this._onDoubleClick = _onDoubleClick; this.getSpanElements = getSpanElements; this.changeTo = changeTo; this.getAbsY = getAbsY; this.getAbsX = getAbsX; this.isStatic = true;
																																						 this.createEditBox = createEditBox; this.getContentText = getContentText; this.containsElement = containsElement; this.getShadowText = getShadowText; this.updateShadow = updateShadow;
																																						 this.multiline = true; this.spellChecker; this.OnCorrection = OnCorrection; this.getNumberOfErrors = getNumberOfErrors; this.getContentCleanHTML = getContentCleanHTML;
																																						 this.targetIsPlain = true; this.unhook = unhook; this.resetCaretPos = unimplementedFunction; this.recordCaretPos = unimplementedFunction; function unimplementedFunction() { } function containsElement(element) { var p;
																																						 if (element == this.iframe) return true; while ((p = element.parentNode)) { if (p == this.iframe) return true; element = p; } return false; } function getAbsX(element, ev) { if (typeof ev.pageX == rsS50[270]) { return ev.pageX - 15;
																																						 } else if (rs_s3.documentElement && rs_s3.documentElement.scrollLeft) { return (ev.clientX + rs_s3.documentElement.scrollLeft) - 15; } else if ((ev.x) && (ev.srcElement) && (!top.opera)) { return (ev.clientX + self.document.body.scrollLeft) - 15;
																																						 } else { return ev.clientX - 15; } } function getAbsY(element, ev) { if (typeof ev.pageY == rsS50[270]) { return ev.pageY - 15; } else if (rs_s3.documentElement && rs_s3.documentElement.scrollTop) { return (ev.clientY + rs_s3.documentElement.scrollTop) - 15;
																																						 } else if ((ev.y) && (ev.srcElement) && (!top.opera)) { return (ev.clientY + self.document.body.scrollTop) - 15; } else { return ev.clientY - 15; } } function changeTo(error, replacement) { var repl = rs_s3.createTextNode(replacement);
																																						 error.parentNode.replaceChild(repl, error); } function findElementsCell(element) { var p = element; while ((p = p.parentNode) != null && p.tagName.toLowerCase() != rsS50[271]) { } return p;
																																						 } function createEditBox(error) { var width = error.offsetWidth; var repl = rs_s3.createElement(rsS50[187]); repl.setAttribute(rsS50[272], rsw_innerHTMLToText(error.innerHTML));
																																						 repl.setAttribute(rsS50[20], rsS50[273]); repl.onkeypress = rsw_inlineTB_onkeypress; repl.onblur = rsw_inlineTB_onBlur; repl.style.width = width * 1.8; error.parentNode.replaceChild(repl, error);
																																						 var scrollTop = this.iframe.scrollTop; repl.focus(); this.iframe.scrollTop = scrollTop; } function getSpanElements() { return this.iframe.getElementsByTagName(rsS50[200]);
																																						 } function _onKeyPress() { rsw_hideCM(); rsw_broadcastToListeners(rsS50[217]); } function _onMouseDown() { rsw_hideCM(); rsw_broadcastToListeners(rsS50[220]); } function _onDoubleClick() { rsw_getTBSHoldingElement(this).spellChecker.OnTextBoxDoubleClicked();
																																						 rsw_broadcastToListeners(rsS50[274]); } function setContent(content) { if (this.targetIsPlain) { var pos = -1; var ppos = 0; var t = rsS50[0]; while ((pos = content.indexOf(rsS50[11], pos + 1)) > -1) { if (pos > ppos + 2) { if (content.substring(pos - 1, pos) == rsS50[100]) t += rsS50[275] + content.substring(ppos, pos - 1) + rsS50[276];
																																						 else t += rsS50[275] + content.substring(ppos, pos) + rsS50[276]; } else t += content.substring(ppos, pos) + rsS50[254]; ppos = pos; } if (ppos < content.length - 1) t += rsS50[275] + content.substring(ppos, content.length) + rsS50[276];
																																						 var flag = false; if (!this.multiline) { var pos = -1; var ppos = 0; var opener = -1; var closer = -1; while ((pos = t.indexOf(rsS50[15], pos + 1)) > -1) { opener = t.lastIndexOf(rsS50[82], pos);
																																						 closer = t.lastIndexOf(rsS50[83], pos); if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) t = t.substring(0, pos) + rsS50[255] + t.substring(pos + 1);
																																						 ppos = pos; } t = rsS50[232] + t + rsS50[233]; } else { var pos = -1; var ppos = 0; var opener = -1; var closer = -1; var flag = true; while ((pos = t.indexOf(rsS50[15], pos + 1)) > -1) { if (pos + 1 < t.length && t.charAt(pos + 1) == rsS50[15]) { opener = t.lastIndexOf(rsS50[82], pos);
																																						 closer = t.lastIndexOf(rsS50[83], pos); if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) { if (flag) t = t.substring(0, pos) + rsS50[255] + t.substring(pos + 1);
																																						 else t = t.substring(0, pos) + rsS50[15] + t.substring(pos + 1); flag = !flag; } ppos = pos; } } } var tabexp = new RegExp(rsS50[277]); while (tabexp.test(t)) t = t.replace(tabexp, rsS50[278]);
																																						 this.iframe.innerHTML = t; } else this.iframe.innerHTML = content; } function getContent() { return this.iframe.innerHTML; } function getContentCleanHTML() { rsw_processedNodes = new Array();
																																						 var nodes = this.iframe.childNodes; var out = rsS50[0]; for (var i = 0; i < nodes.length; i++) { out += rsw_cleanHTML(nodes[i]); } return out; } function isNodeKnownToBeProcessed(node) { if (rsw_processedNodes == null || typeof (node.sourceIndex) == rsS50[9]) return false;
																																						 for (var i = 0; i < rsw_processedNodes.length; i++) { if (node.sourceIndex == rsw_processedNodes[i]) return true; } return false; } var rsw_processedNodes = null;
																																						 function rsw_cleanHTML(node) { var t = rsS50[0]; var styleInAttr = false; if (isNodeKnownToBeProcessed(node)) return t; if (rsw_processedNodes != null && typeof (node.sourceIndex) != rsS50[9]) rsw_processedNodes.push(node.sourceIndex);
																																						 if (node.nodeName.toLowerCase() != rsS50[279] && node.nodeName.toLowerCase() != rsS50[187] && !(node.nodeName.toLowerCase() == rsS50[200] && node.className == rsS50[179]) ) { t += rsS50[82] + node.nodeName + rsS50[15];
																																						 for (var att = 0; node.attributes!=null && att < node.attributes.length; att++) { if (node.attributes[att].nodeValue) { styleInAttr = styleInAttr || node.attributes[att].nodeName.toLowerCase() == rsS50[21];
																																						 t += node.attributes[att].nodeName + "=\"" + node.attributes[att].nodeValue + "\" "; } } if (typeof (node.style) != rsS50[9] && !styleInAttr) { t += "style=\""; t += node.style.cssText;
																																						 t += "\" "; } if (node.childNodes.length == 0 && !node.nodeValue) t += rsS50[280]; t += rsS50[83]; } if (node.childNodes.length == 0) { if (node.nodeValue) { t += node.nodeValue.replace(rsS50[82], rsS50[191]).replace(rsS50[83], rsS50[192]);
																																						 } if (node.value) { t += node.value.replace(rsS50[82], rsS50[191]).replace(rsS50[83], rsS50[192]); } } else { for (var i = 0; i < node.childNodes.length; i++) t += rsw_cleanHTML(node.childNodes[i]);
																																						 } if (node.nodeName.toLowerCase() != rsS50[279] && node.nodeName.toLowerCase() != rsS50[187] && !(node.nodeName.toLowerCase() == rsS50[200] && node.className == rsS50[179]) && !(node.childNodes.length == 0 && !node.nodeValue) ) t += rsS50[84] + node.nodeName + rsS50[83];
																																						 return t; } function getContentText() { var contentElements = this.iframe.childNodes; var contents = rsS50[0]; for (var i = 0; i < contentElements.length; i++) { if (contentElements[i].nodeValue) { contents += contentElements[i].nodeValue;
																																						 } else if (contentElements[i].nodeName.toLowerCase() == rsS50[184]) contents += rsS50[124]; else if (contentElements[i].nodeName.toLowerCase() == rsS50[187]) { contents += contentElements[i].value;
																																						 } else { contents += rsw_innerText(contentElements[i]); } } var t = contents; while (rsw_newlineexp.test(t)) t = t.replace(rsw_newlineexp, rsS50[0]); contents = t;
																																						 return contents; } function _onContextMenu() { rsw_broadcastToListeners(rsS50[234]); return false; } function _onPaste() { rsw_broadcastToListeners(rsS50[237]); } function getShadowText() { return this.shadowTB.value;
																																						 } function updateShadow() { if (this.targetIsPlain) this.spellChecker.tbInterface.setText(this.getContentText()); else this.spellChecker.tbInterface.setText(this.getContentCleanHTML());
																																						 } function initialize() { this.iframe.onmousedown = this._onMouseDown; this.iframe.ondblclick = this._onDoubleClick; var ifID = this.iframe.id; this.shadowTBID = ifID.substring(0, ifID.length - 2);
																																						 this.shadowTB = rs_s3.getElementById(this.shadowTBID); } function unhook() { this.iframe.onmousedown = null; this.iframe.ondblclick = null; } function OnCorrection(e) { if (this.getNumberOfErrors() == 0) { if (this.spellChecker.enterEditModeWhenNoErrors) { this.spellChecker.OnSpellButtonClicked(true);
																																						 } } rsw_broadcastToListeners(rsS50[182]); } function getNumberOfErrors() { var errors = this.getSpanElements(); var numErrors = 0; for (var i = 0; i < errors.length;
																																						 i++) { if (errors[i].className == rsS50[179]) { numErrors++; } } return numErrors; } } function rsw_getElementHeight(Elem) { var op5 = (navigator.userAgent.indexOf(rsS50[281]) != -1) || (navigator.userAgent.indexOf(rsS50[282]) != -1);
																																						 if (rs_s3.layers) { var elem = rsw_getObjNN4(document, Elem); return elem.clip.height; } else { if (rs_s3.getElementById) { var elem = rs_s3.getElementById(Elem);
																																						 } else if (rs_s3.all) { var elem = rs_s3.all[Elem]; } if (op5) { xPos = elem.style.pixelHeight; } else { xPos = elem.offsetHeight; } return xPos; } } function rsw_getObjNN4(obj, name) { var x = obj.layers;
																																						 var foundLayer; for (var i = 0; i < x.length; i++) { if (x[i].id == name) foundLayer = x[i]; else if (x[i].layers.length) var tmp = rsw_getObjNN4(x[i], name); if (tmp) foundLayer = tmp;
																																						 } return foundLayer; } function rsw_getElementWidth(Elem) { var op5 = (navigator.userAgent.indexOf(rsS50[281]) != -1) || (navigator.userAgent.indexOf(rsS50[282]) != -1);
																																						 if (rs_s3.layers) { var elem = rsw_getObjNN4(document, Elem); return elem.clip.width; } else { if (rs_s3.getElementById) { var elem = rs_s3.getElementById(Elem); } else if (rs_s3.all) { var elem = rs_s3.all[Elem];
																																						 } if (op5) { xPos = elem.style.pixelWidth; } else { xPos = elem.offsetWidth; } return xPos; } } function rsw_findPosX(obj) { var curleft = 0; if (typeof (obj.offsetParent) != rsS50[9] && obj.offsetParent) { while (obj.offsetParent) { curleft += obj.offsetLeft;
																																						 obj = obj.offsetParent; } curleft += obj.offsetLeft; } else if (obj.x) curleft += obj.x; return curleft; } function rsw_findPosY(obj) { var curtop = 0; if (typeof (obj.offsetParent) != rsS50[9] && obj.offsetParent) { while (obj.offsetParent) { curtop += obj.offsetTop;
																																						 obj = obj.offsetParent; } curtop += obj.offsetTop; } else if (obj.y) curtop += obj.y; return curtop; } function rsw_decodeSuggestionItem(item) { return unescape(item).replace(rsS50[283], rsS50[89]).replace(rsS50[284], "\"");
																																						 } function RS_ContextMenu(errorElement, suggestions, textBox) { this.suggestions = suggestions; this.CMItems = new Array(); this.x = 0; this.y = 0; this.CMelement = null;
																																						 this.textBox = textBox; this.show = show; this.setCMContent = setCMContent; this.hide = hide; this.setVisible = setVisible; this.moveCMElement = moveCMElement; this.getContentHtml = getContentHtml;
																																						 this.addItems = addItems; this.addItems(); function addItems() { var newSuggs = new Array(); var errorLength = errorElement.textContent ? errorElement.textContent.length : errorElement.innerText.length;
																																						 for (var i = 0; i < this.suggestions.length; i++) { if (this.suggestions[i].indexOf(rsS50[285]) == 0 || this.textBox.maxlength == 0 || typeof(this.textBox.maxlength)==rsS50[9] || rsw_decodeSuggestionItem(this.suggestions[i]).length - errorLength + this.textBox.getContentText().length <= this.textBox.maxlength) newSuggs[newSuggs.length] = this.suggestions[i];
																																						 } this.suggestions = newSuggs; var isDuplicateWordErr = false; for (i = 0; i < this.suggestions.length; i++) { if (this.suggestions[i].indexOf(rsS50[285]) < 0) { this.CMItems[this.CMItems.length] = new RS_ContextMenuItem(errorElement, rsw_decodeSuggestionItem(this.suggestions[i]), escape(this.suggestions[i]), rsS50[225] );
																																						 if (this.textBox.spellChecker.showChangeAllItem) { this.CMItems[this.CMItems.length] = new RS_ContextMenuItem(errorElement, unescape(this.textBox.spellChecker.changeAllText), escape(this.suggestions[i]), rsS50[286], rsS50[287] );
																																						 } } else { this.CMItems[this.CMItems.length] = new RS_ContextMenuItem(errorElement, this.textBox.spellChecker.removeDuplicateText, escape(this.suggestions[i].substring(1)), rsS50[288] );
																																						 isDuplicateWordErr = true; } } if (this.suggestions.length == 0) { this.CMItems[0] = new RS_ContextMenuItem(errorElement, this.textBox.spellChecker.noSuggestionsText, rsS50[104], rsS50[289] );
																																						 i = 1; } else { i = this.CMItems.length; } if (!isDuplicateWordErr || this.textBox.isStatic) { this.CMItems[i] = new RS_ContextMenuItem(errorElement, rsS50[290], rsS50[290], rsS50[290] );
																																						 } if (this.textBox.isStatic) { if (this.textBox.spellChecker.showEditMenuItem) { this.CMItems[i + 1] = new RS_ContextMenuItem(errorElement, this.textBox.spellChecker.editText, rsS50[108], rsS50[291] );
																																						 i++; } } if (!isDuplicateWordErr) { if (this.textBox.spellChecker.showIgnoreAllMenuItem) { this.CMItems[i + 1] = new RS_ContextMenuItem(errorElement, this.textBox.spellChecker.ignoreAllText, rsS50[105], rsS50[292] );
																																						 } else i--; if (this.textBox.spellChecker.showAddMenuItem) { this.CMItems[i + 2] = new RS_ContextMenuItem(errorElement, this.textBox.spellChecker.addText, rsS50[107], rsS50[293] );
																																						 } } if (rs_s3.getElementById(rsS50[294]) == null) rsw_create_menu_div(); this.CMelement = rs_s3.getElementById(rsS50[294]); this.CMIFelement = rs_s3.getElementById(rsS50[295]);
																																						 this.setVisible(false); } function show() { if (typeof(this.textBox.enabled)!=rsS50[9] && !this.textBox.enabled) return; this.setVisible(true); this.moveCMElement();
																																						 this.setCMContent(this.getContentHtml()); if (typeof (rsw_useIFrameMenuBacker) == rsS50[9] || rsw_useIFrameMenuBacker) { if (navigator.userAgent.toLowerCase().indexOf(rsS50[296]) > -1 && !rsw_isMac) { this.CMIFelement.style.left = this.x + rsS50[32];
																																						 this.CMIFelement.style.top = this.y + rsS50[32]; this.CMIFelement.style.height = (rsw_getElementHeight(rsS50[294]) - 4) + rsS50[32]; this.CMIFelement.style.width = (rsw_getElementWidth(rsS50[294]) - 4) + rsS50[32];
																																						 } } } function hide() { this.setVisible(false); this.CMelement.innerHtml = rsS50[0]; } function setCMContent(s) { this.CMelement.innerHTML = s; } function setVisible(visible) { this.CMelement.style.visibility = visible ? rsS50[71] : rsS50[297];
																																						 if (typeof (rsw_useIFrameMenuBacker) == rsS50[9] || rsw_useIFrameMenuBacker) { if (navigator.userAgent.toLowerCase().indexOf(rsS50[296]) > -1 && !rsw_isMac) { this.CMIFelement.style.visibility = visible ? rsS50[71] : rsS50[297];
																																						 this.CMIFelement.style.display = visible ? rsS50[135] : rsS50[24]; } } this.isVisible = visible; } function moveCMElement() { this.CMelement.style.left = this.x + rsS50[32];
																																						 this.CMelement.style.top = this.y + rsS50[32]; if (typeof (rsw_useIFrameMenuBacker) == rsS50[9] || rsw_useIFrameMenuBacker) { if (navigator.userAgent.toLowerCase().indexOf(rsS50[296]) > -1 && !rsw_isMac) { this.CMIFelement.style.left = this.x + rsS50[32];
																																						 this.CMIFelement.style.top = this.y + rsS50[32]; } } } function getContentHtml() { var s = "<table class=\"" + RS_ContextMenuTable_Class + "\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">";
																																						 var hasSubMenu = false; for (var i = 0; i < this.CMItems.length; i++) { hasSubMenu = i < this.CMItems.length - 1 && this.CMItems[i + 1].type == rsS50[287]; s += rsS50[298] + (hasSubMenu ? rsS50[299] : rsS50[300]) + rsS50[83];
																																						 s += this.CMItems[i].getContentHtml(); s += rsS50[301]; if (hasSubMenu) { i++; s += rsS50[302] + this.CMItems[i].getContentHtml() + rsS50[301]; } s += rsS50[303];
																																						 } s += rsS50[304]; return s; } } function RS_ContextMenuItem(e, unescapedValue, escapedValue, action, type) { this.unescapedValue = unescapedValue; this.escapedValue = escapedValue;
																																						 this.action = action; this.getContentHtml = getContentHtml; this.type = type ? type : rsS50[305]; function getContentHtml() { var s; if (this.unescapedValue != rsS50[290] && this.action != rsS50[289]) { s = "<span class=\"" + (this.type == rsS50[305] ? RS_ContextMenuItem_Class : RS_ContextMenuItem_AllSubItem_Class ) + "\" " + " onclick=\"RS_CMItemClicked( '" + this.escapedValue + rsS50[306] + this.action + "') ;\"" + " onMouseOut=\" RS_CMItemHighlight(this, 'out');\" " + " onMouseOver=\"RS_CMItemHighlight(this, 'over'); \" " + rsS50[83] + this.unescapedValue + rsS50[307];
																																						 } else if (this.action == rsS50[289]) { s = "<span class=\"" + RS_ContextMenuItem_Disabled_Class + "\" " + rsS50[83] + this.unescapedValue + rsS50[307]; } else { s = "<hr class=\"" + RS_CMItemSeparator_Class + "\"/>";
																																						 } return s; } } function RS_CMItemHighlight(e, type) { var p = e.className.indexOf(rsS50[308]); if (type == rsS50[309]) { if (p > 0) e.className = e.className.substring(0, p);
																																						 } else { if (p == -1) e.className = e.className + rsS50[308]; } } function RS_CMItemClicked(replacement, action) { var yScroll = null; if (typeof(rsw_activeTextbox.iframe.contentWindow) != rsS50[9]) yScroll = rsw_getScrollY(rsw_activeTextbox.iframe.contentWindow);
																																						 replacement = unescape(replacement).replace(rsS50[283], rsS50[89]).replace(rsS50[284], "\""); if (action == rsS50[292]) { rsw_ignoreAll(rsw_lastRightClickedError);
																																						 } else if (action == rsS50[291]) { rsw_edit(rsw_lastRightClickedError); } else if (action == rsS50[293]) { rsw_add(rsw_lastRightClickedError); } else if (action == rsS50[288]) { rsw_changeTo(rsw_lastRightClickedError, rsS50[0]);
																																						 } else if (action == rsS50[286]) { rsw_changeAllTo(rsw_lastRightClickedError, replacement); } else { rsw_changeTo(rsw_lastRightClickedError, replacement); } rsw_hideCM();
																																						 if (rsw_activeTextbox.focus && !rsw_activeTextbox.isFocused) { rsw_activeTextbox.focus(); if (rsw_activeTextbox.resetCaretPos) rsw_activeTextbox.resetCaretPos(); if(yScroll!=null) rsw_setScrollY(rsw_activeTextbox.iframe.contentWindow, yScroll);
																																						 } } function rsw_hideCM() { if (rsw_contextMenu) { rsw_contextMenu.hide(); } } function rsw_create_menu_div() { var divElement = rs_s3.createElement(rsS50[18]); divElement.id = rsS50[294];
																																						 divElement.setAttribute(rsS50[310], rsS50[311]); try { divElement.oncontextmenu = function () { try { event.cancelBubble = true; event.preventDefault(); } catch (e) { } return false;
																																						 }; } catch (e) { } rs_s3.getElementsByTagName(rsS50[23])[0].appendChild(divElement); if (navigator.userAgent.toLowerCase().indexOf(rsS50[296]) > -1) { var ifElement = rs_s3.createElement(rsS50[312]);
																																						 ifElement.id = rsS50[295]; ifElement.setAttribute(rsS50[313], rsS50[314]); ifElement.setAttribute(rsS50[315], rsS50[316]); ifElement.setAttribute(rsS50[317], rsS50[318]);
																																						 ifElement.setAttribute(rsS50[21], rsS50[319]); rs_s3.getElementsByTagName(rsS50[23])[0].appendChild(ifElement); } } var rsw_ayt_initializing = false; function RapidSpell_Web_AsYouType() { this.triggeredLast = false;
																																						 this.checkerCurrentlyInitializing = 0; this.onTextBoxesInit = onTextBoxesInit; this.checkNext = checkNext; this.onFinish = onFinish; this.onPause = onPause; this.checkAsYouTypeOnPageLoad = true;
																																						 this.stop = stop; this.start = start; this.stopped = false; function start() { this.stopped = false; } function stop() { this.stopped = true; } function onPause() { if (!this.stopped && typeof (rsw_activeTextbox) != rsS50[9] && rsw_activeTextbox != null && rsw_activeTextbox.spellChecker != null) { rsw_activeTextbox.updateShadow();
																																						 rsw_activeTextbox.spellChecker.OnSpellButtonClicked(); } } function onTextBoxesInit() { rsw_ayt_initializing = true; rsw_ayt_check = true; this.checkNext(); } function checkNext() { if (rsw_haltProcesses || !rsw_ayt_enabled || this.stopped) { rsw_ayt_initializing = false;
																																						 this.checkerCurrentlyInitializing++; this.onFinish(); } if (rsw_scs.length > this.checkerCurrentlyInitializing) { var tbs = rsw_scs[this.checkerCurrentlyInitializing].getTBS();
																																						 if (tbs != null && (tbs.isStatic || !tbs.isVisible())) { this.checkerCurrentlyInitializing++; this.onFinish(); } else if (tbs!=null){ if (this.checkAsYouTypeOnPageLoad) rsw_scs[this.checkerCurrentlyInitializing].OnSpellButtonClicked();
																																						 this.checkerCurrentlyInitializing++; if (!this.checkAsYouTypeOnPageLoad) this.onFinish(); tbs.isAYT = true; } } return this.checkerCurrentlyInitializing < rsw_scs.length;
																																						 } function onFinish() { if (!rsw_ayt_initializing) { } if (rsw_ayt_initializing && this.triggeredLast) { rsw_ayt_initializing = false; if (typeof (_notifySpellCheckListeners) != rsS50[9]) _notifySpellCheckListeners(rsS50[320]);
																																						 } if (rsw_ayt_initializing) { this.triggeredLast = !this.checkNext(); } } } String.prototype.rsw_reverse = function () { return this.split(rsS50[0]).reverse().join(rsS50[0]);
																																						 }; function RSW_Diff(p, v, a) { this.position = p; this.vector = v; this.addedText = a; } function RSW_VisibleCharSeq(str) { this.str = str; this.length = str.length;
																																						 this.allVisible = false; this.reverse = reverse; this.isReversed = false; function reverse() { this.str = this.str.rsw_reverse(); this.isReversed = !this.isReversed;
																																						 } this.insertAtVisible = insertAtVisible; function insertAtVisible(addition, pos) { return this.visibleSubstring(0, pos) + addition + this.visibleSubstring(pos, this.visibleLength());
																																						 } this.toString = toString; function toString() { return this.str; } this.visibleSubstring = visibleSubstring; function visibleSubstring(start, end) { var visiChars = 0;
																																						 var inTag = false; var inEnt = false; var sub = rsS50[0]; var includeTags = true; var tagOpen = this.isReversed ? rsS50[83] : rsS50[82]; var tagClose = this.isReversed ? rsS50[82] : rsS50[83];
																																						 var entOpen = this.isReversed ? rsS50[321] : rsS50[189]; var entClose = this.isReversed ? rsS50[189] : rsS50[321]; for (var i = 0; i < this.str.length; i++) { if (this.str.charAt(i) == tagOpen && !inTag && !this.allVisible) inTag = true;
																																						 if (this.str.charAt(i) == entOpen && !inTag && !inEnt && !this.allVisible) { var closer = this.str.indexOf(entClose, i); if (closer > -1 && closer - i < 9) { inEnt = true;
																																						 if (visiChars >= start && visiChars < end) { var entity = this.str.substring(i, closer); if (entity == rsS50[322]) sub += rsS50[189]; if (entity == rsS50[323]) sub += rsS50[15];
																																						 if (entity == rsS50[324]) sub += rsS50[82]; if (entity == rsS50[325]) sub += rsS50[83]; } visiChars++; } } if (includeTags && inTag && visiChars >= start && visiChars <= end) sub += this.str.charAt(i);
																																						 if (!inTag && !inEnt) { if ( visiChars >= start && visiChars < end) sub += this.str.charAt(i); visiChars++; } if (this.str.charAt(i) == tagClose && inTag) inTag = false;
																																						 if (this.str.charAt(i) == entClose && inEnt) inEnt = false; } return sub; } this.lastDiffI = 0; this.lastDiffPos = 0; this.visibleCharAt = visibleCharAt; function visibleCharAt(pos) { var startI = 0;
																																						 var visiChars = 0; var tagOpen = this.isReversed ? rsS50[83] : rsS50[82]; var tagClose = this.isReversed ? rsS50[82] : rsS50[83]; var entOpen = this.isReversed ? rsS50[321] : rsS50[189];
																																						 var entClose = this.isReversed ? rsS50[189] : rsS50[321]; var entityChar; if (pos > this.lastDiffPos) { startI = this.lastDiffI; visiChars = this.lastDiffPos; } var inTag = false;
																																						 var inEnt = false; for (var i = startI; i < this.str.length; i++) { if (this.str.charAt(i) == tagOpen && !inTag && !this.allVisible) inTag = true; if (this.str.charAt(i) == entOpen && !inTag && !inEnt && !this.allVisible) { var closer = this.str.indexOf(entClose, i);
																																						 if (closer > -1 && closer - i < 9) { inEnt = true; var entity = this.str.substring(i, closer); if (entity == rsS50[322]) entityChar = rsS50[189]; if (entity == rsS50[323]) entityChar = rsS50[15];
																																						 if (entity == rsS50[324]) entityChar = rsS50[82]; if (entity == rsS50[325]) entityChar = rsS50[83]; if (visiChars == pos) return entityChar; visiChars++; } } if (!inTag && !inEnt) { if (visiChars == pos) { this.lastDiffI = i;
																																						 this.lastDiffPos = visiChars; if (this.str.charAt(i) == String.fromCharCode(160)) return rsS50[15]; if (this.str.charAt(i) == rsS50[100]) return rsS50[11]; return this.str.charAt(i);
																																						 } visiChars++; } if (this.str.charAt(i) == tagClose && inTag) inTag = false; if (this.str.charAt(i) == entClose && inEnt) inEnt = false; } } this.visibleLength = visibleLength;
																																						 function visibleLength() { var visiChars = 0; var inTag = false; var inEnt = false; for (var i = 0; i < this.str.length; i++) { if (this.str.charAt(i) == rsS50[82] && !inTag && !this.allVisible) inTag = true;
																																						 if (this.str.charAt(i) == rsS50[189] && !inTag && !inEnt && !this.allVisible) { var closer = this.str.indexOf(rsS50[321], i); if (closer > -1 && closer - i < 9) { inEnt = true;
																																						 visiChars++; } } if (!inTag && !inEnt) { visiChars++; } if (this.str.charAt(i) == rsS50[83] && inTag) inTag = false; if (this.str.charAt(i) == rsS50[321] && inEnt) inEnt = false;
																																						 } return visiChars; } } function RSW_diff(beforeS, afterS) { var cs = -1; var ce = -1; var scanLength = 0; var before = new RSW_VisibleCharSeq(beforeS); var after = new RSW_VisibleCharSeq(afterS);
																																						 after.allVisible = true; var beforeVisiLen = before.visibleLength(); var afterVisiLen = after.visibleLength(); for (var i = 0; i < beforeVisiLen && cs < 0; i++) if (!(i >= afterVisiLen || after.visibleCharAt(i) == before.visibleCharAt(i))) cs = i;
																																						 if (cs == -1 && afterVisiLen != beforeVisiLen) cs = beforeVisiLen; after.reverse(); before.reverse(); for (var i = 0; i < afterVisiLen && ce < 0; i++) if (i >= (beforeVisiLen - cs) || !(i >= beforeVisiLen || after.visibleCharAt(i) == before.visibleCharAt(i))) ce = (afterVisiLen - i);
																																						 if (ce == -1) ce = afterVisiLen; var vector = ce - cs; if (vector == 0) vector = afterVisiLen - beforeVisiLen; after.reverse(); return new RSW_Diff(cs, vector, after.visibleSubstring(cs, ce));
																																						 } function RSW_EditableElementFinder() { this.findPlainTargetElement = findPlainTargetElement; this.findRichTargetElements = findRichTargetElements; this.obtainElementWithInnerHTML = obtainElementWithInnerHTML;
																																						 this.findEditableElements = findEditableElements; this.elementIsEditable = elementIsEditable; this.getEditableContentDocument = getEditableContentDocument; function findPlainTargetElement(elementID) { var rsw_elected = rs_s3.getElementById(elementID);
																																						 if (rsw_elected != null && rsw_elected.tagName && (rsw_elected.tagName.toUpperCase() == rsS50[326] || rsw_elected.tagName.toUpperCase() == rsS50[327])) { return rsw_elected;
																																						 } else return null; } function findRichTargetElements(debugTextBox) { var editables = new Array(); this.findEditableElements(document, editables, window, rsS50[0], debugTextBox);
																																						 return editables; } function obtainElementWithInnerHTML(editable) { if (typeof (editable.innerHTML) != rsS50[9]) return editable; else if (typeof (editable.documentElement) != rsS50[9]) return editable.documentElement;
																																						 return null; } function findEditableElements(node, editables, parent, debugInset, debugTextBox) { var children = node.childNodes; var editableElement; if ((editableElement = this.elementIsEditable(node)) != null || (editableElement = this.getEditableContentDocument(node, debugTextBox)) != null ) { editables[editables.length] = editableElement;
																																						 } for (var i = 0; i < children.length; i++) { this.findEditableElements(children[i], editables, node, debugInset + rsS50[15], debugTextBox); } } function elementIsEditable(element) { if ( ( typeof (element.getAttribute) != rsS50[9] && ( element.getAttribute(rsS50[224]) == rsS50[119] || element.getAttribute(rsS50[328]) == rsS50[258] ) ) || ( (element.contentEditable && element.contentEditable == true) || (element.designMode && element.designMode.toLowerCase() == rsS50[258]) ) ) return [element, element];
																																						 else return null; } function getEditableContentDocument(element, debugTextBox) { if (element.tagName && element.tagName == rsS50[312]) { var kids = new Array(); if (element.contentWindow && element.contentWindow.document) { this.findEditableElements(element.contentWindow.document, kids, element, rsS50[329], debugTextBox);
																																						 if (kids.length > 0) { var editable = kids[0][0]; if (typeof (editable.body) != rsS50[9]) editable = editable.body; return [editable, element]; } } } return null;
																																						 } } var rsw_require_init = true; function rsw_ASPNETAJAX_OnInitializeRequest(sender, eventArgs) { rsw_cancelCall = true; rsw_haltProcesses = true; rsw_require_init = true;
																																						 for (var i = 0; i < rsw_scs.length; i++) { if (rsw_scs[i].state == rsS50[136]) { rsw_scs[i].rsw_tbs.updateShadow(); rsw_scs[i].rsw_tbs.iframe.style.display = rsS50[24];
																																						 } rsw_scs[i].rsw_tbs = null; } rsw_tbs = new Array(); } function rsw_ASPNETAJAX_OnEndRequest(sender, eventArgs) { rsw_haltProcesses = false; rsw_createLink(document, rsw_rs_menu_styleURL);
																																						 rsw_createLink(document, rsw_rs_styleURL); if (typeof (attachInitHandler) != rsS50[9]) attachInitHandler(); if (rsw_require_init) { if (typeof (rsw_autoCallRSWInit) == rsS50[9] || rsw_autoCallRSWInit) setTimeout(rsS50[330], 200);
																																						 } rsw_require_init = false; } if (typeof (Sys) != rsS50[9] && typeof (Sys.Application) != rsS50[9]) Sys.Application.notifyScriptLoaded(); 

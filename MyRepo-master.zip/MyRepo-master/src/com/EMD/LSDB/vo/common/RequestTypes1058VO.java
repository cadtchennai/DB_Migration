package com.EMD.LSDB.vo.common;

public class RequestTypes1058VO extends EMDVO{
	private int requestTypeSeqNo;
	private String requestTypeName=null;
	public String getRequestTypeName() {
		return requestTypeName;
	}
	public void setRequestTypeName(String requestTypeName) {
		this.requestTypeName = requestTypeName;
	}
	public int getRequestTypeSeqNo() {
		return requestTypeSeqNo;
	}
	public void setRequestTypeSeqNo(int requestTypeSeqNo) {
		this.requestTypeSeqNo = requestTypeSeqNo;
	}
	
}

package com.EMD.LSDB.vo.common;

public class RequestCategories1058VO extends EMDVO{
	private int categorySeqNo;
	private String categoryName =null;
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public int getCategorySeqNo() {
		return categorySeqNo;
	}
	public void setCategorySeqNo(int categorySeqNo) {
		this.categorySeqNo = categorySeqNo;
	}
	

}

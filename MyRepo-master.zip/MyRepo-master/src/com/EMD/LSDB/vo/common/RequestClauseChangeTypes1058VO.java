package com.EMD.LSDB.vo.common;

public class RequestClauseChangeTypes1058VO extends EMDVO{
	private int changeTypeSeqNo;
	private String changeTypeName=null;
	public String getChangeTypeName() {
		return changeTypeName;
	}
	public void setChangeTypeName(String changeTypeName) {
		this.changeTypeName = changeTypeName;
	}
	public int getChangeTypeSeqNo() {
		return changeTypeSeqNo;
	}
	public void setChangeTypeSeqNo(int changeTypeSeqNo) {
		this.changeTypeSeqNo = changeTypeSeqNo;
	}
	

}

/*
 * Created on Jun 5, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.EMD.LSDB.common.resourceloader;

/**
 * @author mm57219
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface EMDResourceLoaderConstants {
	
	public static final String java_env = "java:comp/env";
	
	public static final String APP_RESOURCE_FILE = "APP_RESOURCE_FILE";
	
	public static final String LOCK = "LOCK";
	
}

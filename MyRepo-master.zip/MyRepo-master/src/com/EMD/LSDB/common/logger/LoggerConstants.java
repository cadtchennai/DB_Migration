/*
 * Created on Jun 5, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.EMD.LSDB.common.logger;

/**
 * @author mm57219
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface LoggerConstants {
	
	public static final String ERR_MSG = "ERR_MSG";
	
	public static final String Log_Level = "invalid deserialized object:  label = ";
	
	public static final String LOCK = "LOCK";
	
	public static final String Logger_AppName = "EMD";
}

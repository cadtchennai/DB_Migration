/*
 * Created on Jun 5, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.EMD.LSDB.common.errorhandler;

/**
 * @author mm57219
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface ErrorConstants {
	
	public static final String ERR_MSG = "ERR_MSG";
	
	public static final String ERR_LVL = "ERR_LVL";
	
	public static final String ERR_TYPE = "ERR_TYPE";
	
	//Error messages
	//public static final String Errror_Level = "invalid deserialized object:  m_label = ";
	//public static final String Errror_Type = "invalid deserialized object:  m_label = ";
	
}

package com.EMD.LSDB.bo.MasterMaintenance;

import com.EMD.LSDB.bo.serviceinterface.ComponentBI;

public class ComponentBO implements ComponentBI {
	
}

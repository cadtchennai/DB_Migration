package com.EMD.LSDB.bo.serviceinterface;

public interface ComponentBI {
	
}

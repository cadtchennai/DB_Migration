package com.EMD.LSDB.form.SpecMaintenance;

import com.EMD.LSDB.form.common.EMDForm;

public class OrderPartOfForm extends EMDForm {
	
}
